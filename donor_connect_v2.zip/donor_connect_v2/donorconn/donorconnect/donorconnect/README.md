# DonorConnect — Blood Bank Inventory & Donor Management System
## Monolithic Spring Boot Backend

---

## Tech Stack
| Layer       | Technology                          |
|-------------|-------------------------------------|
| Backend     | Spring Boot 3.2, Java 17            |
| Security    | Spring Security + JWT (JJWT 0.11.5) |
| Database    | MySQL 8.x                           |
| ORM         | Spring Data JPA / Hibernate         |
| API Docs    | SpringDoc OpenAPI 2.3 (Swagger UI)  |
| Build Tool  | Maven                               |

---

## Project Structure
```
donorconnect/
├── pom.xml
└── src/main/
    ├── java/com/donorconnect/
    │   ├── DonorConnectApplication.java
    │   ├── config/
    │   │   ├── SecurityConfig.java
    │   │   ├── SwaggerConfig.java
    │   │   └── GlobalExceptionHandler.java
    │   ├── controller/          (18 controllers — all modules)
    │   ├── service/             (15 services)
    │   ├── repository/          (22 JPA repositories)
    │   ├── entity/              (21 JPA entities)
    │   ├── dto/request/         (26 request DTOs)
    │   ├── dto/response/        (ApiResponse wrapper)
    │   ├── enums/               (all enums in Enums.java)
    │   ├── security/            (JWT filter, provider, UserDetailsService)
    │   └── scheduler/           (ExpiryWatchScheduler)
    └── resources/
        └── application.properties
```

---

## Prerequisites
- Java 17+
- Maven 3.8+
- MySQL 8.x running locally

---

## Setup & Run

### 1. Create MySQL Database
```sql
CREATE DATABASE donorconnect_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```
(Or let Spring auto-create it — `createDatabaseIfNotExist=true` is set in properties.)

### 2. Configure Database Credentials
Edit `src/main/resources/application.properties`:
```properties
spring.datasource.username=root
spring.datasource.password=root   ← change to your MySQL password
```

### 3. Build & Run
```bash
cd donorconnect
mvn clean install -DskipTests
mvn spring-boot:run
```

Server starts at: **http://localhost:8080**

### 4. Verify Startup
```
DonorConnect started on port 8080
Swagger UI: http://localhost:8080/swagger-ui.html
```

Tables are auto-created by Hibernate (`ddl-auto=update`).

---

## Create First Admin User

Since registration requires ADMIN role, seed the first user directly in MySQL:

```sql
-- BCrypt hash of "Admin@1234"
INSERT INTO users (name, role, email, phone, password, status)
VALUES (
  'System Admin',
  'ROLE_ADMIN',
  'admin@donorconnect.com',
  '9000000000',
  '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lHHi',
  'ACTIVE'
);
```

---

## Swagger UI (API Documentation)

**URL:** http://localhost:8080/swagger-ui.html

1. Open Swagger UI
2. Click **Authorize** (lock icon, top right)
3. Login first via `POST /api/v1/auth/login` to get JWT token
4. Enter `Bearer <token>` in the Authorize box
5. All endpoints become accessible

---

## Postman Testing

### Import Collection
1. Open Postman
2. Click **Import** → select `DonorConnect_Postman_Collection.json`
3. Collection variable `baseUrl` = `http://localhost:8080/api/v1`

### Workflow (follow this order)
```
1. Auth → Login              ← auto-saves token to {{token}} variable
2. Donors → Register Donor
3. Screening → Create Screening
4. Donations → Record Donation
5. Test Results → Enter HIV / HBV / HCV / VDRL / Malaria results
6. Components → Create PRBC / Platelet / Plasma
7. Inventory → Record Stock Transaction (RECEIPT)
8. Crossmatch → Create Request → Record Result
9. Issue → Issue Blood to Patient
10. Reactions → Log Reaction (if any)
11. Reports → View all analytics
```

### Login Auto-Token Script
The Login request has a Postman test script that automatically saves
the JWT token to `{{token}}`. All subsequent requests use it via
Bearer Auth at the collection level.

---

## API Overview (153 Endpoints)

| Module                    | Base Path               | Endpoints |
|---------------------------|-------------------------|-----------|
| Authentication            | /api/v1/auth            | 5         |
| User Management           | /api/v1/users           | 8         |
| Audit Logs                | /api/v1/audit-logs      | 3         |
| Donor Registration        | /api/v1/donors          | 9         |
| Screening                 | /api/v1/screenings      | 4         |
| Deferrals                 | /api/v1/deferrals       | 6         |
| Appointments              | /api/v1/appointments    | 10        |
| Drives                    | /api/v1/drives          | 7         |
| Donations                 | /api/v1/donations       | 7         |
| Test Results              | /api/v1/test-results    | 6         |
| Components                | /api/v1/components      | 8         |
| Inventory & Stock         | /api/v1/inventory       | 13        |
| Crossmatch & Issue        | /api/v1/crossmatch      | 15        |
| Reactions & Lookback      | /api/v1/reactions       | 11        |
| Recalls / Quarantine      | /api/v1/recalls         | 14        |
| Billing                   | /api/v1/billing         | 6         |
| Reports & Analytics       | /api/v1/reports         | 12        |
| Notifications             | /api/v1/notifications   | 9         |
| Admin Config              | /api/v1/admin/config    | 6         |

---

## Roles Reference

| Role                     | Access                                         |
|--------------------------|------------------------------------------------|
| ROLE_ADMIN               | Full access to everything                      |
| ROLE_RECEPTION           | Donors, Screening, Deferrals, Appointments     |
| ROLE_PHLEBOTOMIST        | Donations collection                           |
| ROLE_LAB_TECHNICIAN      | Test results, Component processing             |
| ROLE_TRANSFUSION_OFFICER | Crossmatch, Issue, Reactions                   |
| ROLE_INVENTORY_CONTROLLER| Inventory, Stock, Expiry, Quarantine, Disposal |
| ROLE_DONOR               | Book/cancel own appointments                   |

---

## Scheduler Jobs

| Job                    | Schedule         | Description                              |
|------------------------|------------------|------------------------------------------|
| Expiry Watch Scan      | Daily 6:00 AM    | Flags components expiring in ≤3 days     |
| Auto-expire Components | Daily 6:00 AM    | Marks past-expiry components as EXPIRED  |
| Low Stock Scan         | Daily 7:00 AM    | Logs low stock (for future alerts)       |

Configure warning days in `application.properties`:
```properties
app.expiry.warning-days=3
```

---

## All Response Format

Every API returns:
```json
{
  "success": true,
  "message": "Success",
  "data": { ... },
  "timestamp": "2025-01-21T10:30:00"
}
```

---

## Phase-1 Limitations
- No analyzer/HIS integration — test results entered manually
- SMS/email alerts are in-app only (Notification entity)
- Password reset token stored in-memory (use Redis in production)
- No payment gateway — billing is reference only

---

## Common Issues

| Problem | Fix |
|---------|-----|
| `Access Denied` | Check your role has permission for that endpoint |
| `401 Unauthorized` | JWT missing or expired — re-login |
| DB connection refused | Ensure MySQL running on port 3306 |
| Port 8080 busy | Change `server.port` in application.properties |
