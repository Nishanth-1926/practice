package com.donorconnect.dto.request.appointment;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class AppointmentRequest {
    @NotNull private Long donorId;
    private LocalDateTime dateTime;
    private Long centerId;
    private Long driveId;
}
