package com.donorconnect.service.report;

import com.donorconnect.entity.collection.BloodComponent;
import com.donorconnect.entity.report.LabReportPack;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.exception.ResourceNotFoundException;
import com.donorconnect.repository.collection.BloodComponentRepository;
import com.donorconnect.repository.collection.DonationRepository;
import com.donorconnect.repository.collection.TestResultRepository;
import com.donorconnect.repository.donor.DeferralRepository;
import com.donorconnect.repository.donor.DonorRepository;
import com.donorconnect.repository.report.LabReportPackRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class ReportService {

    private final LabReportPackRepository labReportPackRepository;
    private final BloodComponentRepository bloodComponentRepository;
    private final DonorRepository donorRepository;
    private final DonationRepository donationRepository;
    private final TestResultRepository testResultRepository;
    private final DeferralRepository deferralRepository;

    public Map<String, Object> getInventorySnapshot() {
        Map<String, Object> result = new LinkedHashMap<>();
        for (ComponentType type : ComponentType.values()) {
            long count = bloodComponentRepository.findByComponentType(type).stream()
                    .filter(c -> c.getStatus() == ComponentStatus.AVAILABLE).count();
            result.put(type.name(), count);
        }
        return result;
    }

    public List<BloodComponent> getExpiryRisk() {
        return bloodComponentRepository.findByExpiryDateBetween(LocalDate.now(), LocalDate.now().plusDays(7));
    }

    public Map<String, Long> getDonorActivity() {
        Map<String, Long> result = new LinkedHashMap<>();
        result.put("ACTIVE",   donorRepository.findAll().stream().filter(d -> d.getStatus() == DonorStatus.ACTIVE).count());
        result.put("DEFERRED", donorRepository.findAll().stream().filter(d -> d.getStatus() == DonorStatus.DEFERRED).count());
        result.put("INACTIVE", donorRepository.findAll().stream().filter(d -> d.getStatus() == DonorStatus.INACTIVE).count());
        result.put("TOTAL",    (long) donorRepository.findAll().size());
        return result;
    }

    public Map<String, Object> getDonationFrequency() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("totalDonations", donationRepository.count());
        result.put("thisMonth", donationRepository.findAll().stream()
                .filter(d -> d.getCollectionDate() != null &&
                        d.getCollectionDate().getMonth() == LocalDate.now().getMonth()).count());
        return result;
    }

    public Map<String, Object> getComponentWastage() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("expired",  bloodComponentRepository.findByStatus(ComponentStatus.EXPIRED).size());
        result.put("disposed", bloodComponentRepository.findByStatus(ComponentStatus.DISPOSED).size());
        return result;
    }

    public Map<String, Long> getReactiveCount() {
        Map<String, Long> result = new LinkedHashMap<>();
        for (TestType type : TestType.values()) {
            long count = testResultRepository.findByStatus(TestStatus.REACTIVE).stream()
                    .filter(t -> t.getTestType() == type).count();
            result.put(type.name(), count);
        }
        return result;
    }

    public Map<String, Object> getDeferralTrends() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("totalDeferrals", deferralRepository.count());
        result.put("temporary", deferralRepository.findAll().stream()
                .filter(d -> d.getDeferralType() == DeferralType.TEMPORARY).count());
        result.put("permanent", deferralRepository.findAll().stream()
                .filter(d -> d.getDeferralType() == DeferralType.PERMANENT).count());
        return result;
    }

    public Map<String, String> getTAT() {
        Map<String, String> result = new LinkedHashMap<>();
        result.put("note", "TAT tracking requires analyzer integration (Phase-2)");
        result.put("totalDonations", String.valueOf(donationRepository.count()));
        result.put("completedTests", String.valueOf(testResultRepository.findByStatus(TestStatus.COMPLETED).size()));
        return result;
    }

    public Map<String, Object> getUtilization() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("available",  bloodComponentRepository.findByStatus(ComponentStatus.AVAILABLE).size());
        result.put("issued",     bloodComponentRepository.findByStatus(ComponentStatus.ISSUED).size());
        result.put("expired",    bloodComponentRepository.findByStatus(ComponentStatus.EXPIRED).size());
        result.put("quarantine", bloodComponentRepository.findByStatus(ComponentStatus.QUARANTINE).size());
        return result;
    }

    public LabReportPack generateReport(ReportScope scope) {
        Map<String, Object> metrics = new LinkedHashMap<>();
        metrics.put("inventorySnapshot", getInventorySnapshot());
        metrics.put("donorActivity", getDonorActivity());
        metrics.put("wastage", getComponentWastage());
        LabReportPack pack = LabReportPack.builder()
                .scope(scope).metricsJson(metrics.toString()).generatedDate(LocalDateTime.now()).build();
        return labReportPackRepository.save(pack);
    }

    public LabReportPack getPackById(Long packId) {
        return labReportPackRepository.findById(packId)
                .orElseThrow(() -> new ResourceNotFoundException("LabReportPack", packId));
    }

    public Page<LabReportPack> getAllPacks(Pageable pageable) {
        return labReportPackRepository.findAll(pageable);
    }
}