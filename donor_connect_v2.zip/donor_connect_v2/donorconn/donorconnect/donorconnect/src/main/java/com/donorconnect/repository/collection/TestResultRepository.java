package com.donorconnect.repository.collection;

import com.donorconnect.entity.collection.TestResult;
import com.donorconnect.enums.Enums.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TestResultRepository extends JpaRepository<TestResult, Long> {
    List<TestResult> findByDonationId(Long donationId);
    List<TestResult> findByStatus(TestStatus status);
}
