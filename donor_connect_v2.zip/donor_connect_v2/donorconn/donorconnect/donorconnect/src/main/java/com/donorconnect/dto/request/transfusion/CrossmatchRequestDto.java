package com.donorconnect.dto.request.transfusion;
import com.donorconnect.enums.Enums.*;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;

@Data
public class CrossmatchRequestDto {
    @NotNull private Long patientId;
    private String orderBy;
    private String bloodGroup;
    private String rhFactor;
    private Integer requiredUnits;
    private CrossmatchPriority priority;
    private LocalDate requestDate;
}
