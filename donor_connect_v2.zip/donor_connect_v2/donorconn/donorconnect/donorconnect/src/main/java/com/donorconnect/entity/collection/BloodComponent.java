package com.donorconnect.entity.collection;

import com.donorconnect.enums.Enums.*;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "components")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BloodComponent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long componentId;

    @Column(nullable = false)
    private Long donationId;

    @Enumerated(EnumType.STRING)
    private ComponentType componentType;

    private String bagNumber;

    private Integer volume;

    private LocalDate manufactureDate;

    private LocalDate expiryDate;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private ComponentStatus status = ComponentStatus.AVAILABLE;
}