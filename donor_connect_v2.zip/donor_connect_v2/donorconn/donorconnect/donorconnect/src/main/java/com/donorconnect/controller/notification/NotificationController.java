package com.donorconnect.controller.notification;

import com.donorconnect.dto.request.notification.NotificationRequest;
import com.donorconnect.dto.response.ApiResponse;
import com.donorconnect.entity.auth.User;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.service.notification.NotificationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/notifications")
@RequiredArgsConstructor
@Tag(name = "Notifications", description = "In-app notifications and alerts")
public class NotificationController {

    private final NotificationService notificationService;

    @PostMapping
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Create notification manually")
    public ResponseEntity<ApiResponse<?>> create(@RequestBody NotificationRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Notification created", notificationService.create(request)));
    }

    @GetMapping
    @Operation(summary = "Get own notifications")
    public ResponseEntity<ApiResponse<?>> getMine(Authentication auth) {
        User user = (User) auth.getPrincipal();
        return ResponseEntity.ok(ApiResponse.success(notificationService.getForUser(user.getUserId())));
    }

    @GetMapping("/{notificationId}")
    @Operation(summary = "Get notification by ID")
    public ResponseEntity<ApiResponse<?>> getById(@PathVariable Long notificationId) {
        return ResponseEntity.ok(ApiResponse.success(notificationService.getById(notificationId)));
    }

    @GetMapping("/unread")
    @Operation(summary = "Get unread notifications")
    public ResponseEntity<ApiResponse<?>> getUnread(Authentication auth) {
        User user = (User) auth.getPrincipal();
        return ResponseEntity.ok(ApiResponse.success(notificationService.getUnreadForUser(user.getUserId())));
    }

    @GetMapping("/category/{category}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Filter notifications by category")
    public ResponseEntity<ApiResponse<?>> getByCategory(@PathVariable NotificationCategory category) {
        return ResponseEntity.ok(ApiResponse.success(notificationService.getByCategory(category)));
    }

    @PatchMapping("/{notificationId}/read")
    @Operation(summary = "Mark notification as read")
    public ResponseEntity<ApiResponse<?>> markRead(@PathVariable Long notificationId) {
        return ResponseEntity.ok(ApiResponse.success("Marked as read", notificationService.markRead(notificationId)));
    }

    @PatchMapping("/{notificationId}/dismiss")
    @Operation(summary = "Dismiss notification")
    public ResponseEntity<ApiResponse<?>> dismiss(@PathVariable Long notificationId) {
        return ResponseEntity.ok(ApiResponse.success("Dismissed", notificationService.dismiss(notificationId)));
    }

    @PatchMapping("/read-all")
    @Operation(summary = "Mark all notifications as read")
    public ResponseEntity<ApiResponse<?>> markAllRead(Authentication auth) {
        User user = (User) auth.getPrincipal();
        notificationService.markAllReadForUser(user.getUserId());
        return ResponseEntity.ok(ApiResponse.success("All marked as read", null));
    }

    @DeleteMapping("/{notificationId}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Delete notification")
    public ResponseEntity<ApiResponse<?>> delete(@PathVariable Long notificationId) {
        notificationService.delete(notificationId);
        return ResponseEntity.ok(ApiResponse.success("Notification deleted", null));
    }
}
