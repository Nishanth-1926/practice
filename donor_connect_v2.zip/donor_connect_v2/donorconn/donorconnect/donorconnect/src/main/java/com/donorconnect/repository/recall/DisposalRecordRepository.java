package com.donorconnect.repository.recall;

import com.donorconnect.entity.recall.DisposalRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface DisposalRecordRepository extends JpaRepository<DisposalRecord, Long> {
    List<DisposalRecord> findByComponentId(Long componentId);
}
