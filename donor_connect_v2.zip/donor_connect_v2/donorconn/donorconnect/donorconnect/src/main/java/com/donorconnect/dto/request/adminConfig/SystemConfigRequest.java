package com.donorconnect.dto.request.adminConfig;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class SystemConfigRequest {
    @NotBlank private String key;
    private String value;
    private String scope;
    private String updatedBy;
}
