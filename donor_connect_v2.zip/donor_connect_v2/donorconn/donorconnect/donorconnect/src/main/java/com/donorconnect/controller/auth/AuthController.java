package com.donorconnect.controller.auth;

import com.donorconnect.dto.request.auth.*;
import com.donorconnect.dto.response.ApiResponse;
import com.donorconnect.entity.auth.User;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.repository.auth.UserRepository;
import com.donorconnect.service.auth.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Authentication", description = "Login, register, password management")
public class AuthController {

    private final AuthService authService;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    // ✅ PUBLIC - No token needed - Creates first admin only if no admin exists
    @PostMapping("/setup-admin")
    @Operation(summary = "One-time admin setup - only works if no admin exists yet")
    public ResponseEntity<ApiResponse<?>> setupAdmin(@RequestBody Setupadminrequest request) {
        // Check if any admin already exists
        boolean adminExists = userRepository.findByRole(UserRole.ROLE_ADMIN).size() > 0;
        if (adminExists) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error("Admin already exists. Use login instead."));
        }
        User admin = User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .phone(request.getPhone())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(UserRole.ROLE_ADMIN)
                .status(UserStatus.ACTIVE)
                .build();
        userRepository.save(admin);
        log.info("First admin created: {}", request.getEmail());
        return ResponseEntity.ok(ApiResponse.success(
                "Admin created successfully. Now login to get your token.", null));
    }

    // ✅ PUBLIC - No token needed
    @PostMapping("/login")
    @Operation(summary = "Login with email and password - returns Bearer token")
    public ResponseEntity<ApiResponse<?>> login(@RequestBody LoginRequest request) {
        log.info("Login attempt for: {}", request.getEmail());
        try {
            var result = authService.login(request);
            log.info("Login success for: {}", request.getEmail());
            return ResponseEntity.ok(ApiResponse.success("Login successful", result));
        } catch (Exception e) {
            log.error("Login failed for {}: {}", request.getEmail(), e.getMessage());
            return ResponseEntity.status(401)
                    .body(ApiResponse.error("Invalid email or password"));
        }
    }

    // ✅ PROTECTED - Requires ADMIN token - Register any role user
    @PostMapping("/register")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Register new user (Admin token required) - can assign any role")
    public ResponseEntity<ApiResponse<?>> register(@RequestBody RegisterRequest request) {
        log.info("Registering new user: {} with role: {}", request.getEmail(), request.getRole());
        return ResponseEntity.ok(ApiResponse.success("User registered successfully",
                authService.register(request)));
    }

    // ✅ PROTECTED - Any logged-in user
    @PutMapping("/change-password")
    @Operation(summary = "Change own password (token required)")
    public ResponseEntity<ApiResponse<?>> changePassword(@RequestBody ChangePasswordRequest request,
                                                         Authentication auth) {
        authService.changePassword(auth.getName(), request);
        return ResponseEntity.ok(ApiResponse.success("Password changed successfully", null));
    }

    // ✅ PUBLIC
    @PostMapping("/forgot-password")
    @Operation(summary = "Request password reset")
    public ResponseEntity<ApiResponse<?>> forgotPassword(@RequestParam String email) {
        return ResponseEntity.ok(ApiResponse.success(authService.forgotPassword(email), null));
    }

    // ✅ PUBLIC
    @PostMapping("/reset-password")
    @Operation(summary = "Reset password")
    public ResponseEntity<ApiResponse<?>> resetPassword(@RequestBody ResetPasswordRequest request) {
        return ResponseEntity.ok(ApiResponse.success(authService.resetPassword(request), null));
    }
}