package com.donorconnect.service.reaction;

import com.donorconnect.dto.request.reaction.LookbackRequest;
import com.donorconnect.dto.request.reaction.ReactionRequest;
import com.donorconnect.entity.reaction.LookbackTrace;
import com.donorconnect.entity.reaction.Reaction;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.exception.ResourceNotFoundException;
import com.donorconnect.repository.reaction.LookbackTraceRepository;
import com.donorconnect.repository.reaction.ReactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReactionService {

    private final ReactionRepository reactionRepository;
    private final LookbackTraceRepository lookbackTraceRepository;

    // --- REACTIONS ---

    public Reaction create(ReactionRequest req) {
        Reaction r = Reaction.builder()
                .issueId(req.getIssueId())
                .patientId(req.getPatientId())
                .reactionType(req.getReactionType())
                .severity(req.getSeverity())
                .reactionDate(req.getReactionDate() != null ? req.getReactionDate() : LocalDate.now())
                .notes(req.getNotes())
                .status(ReactionStatus.PENDING)
                .build();
        return reactionRepository.save(r);
    }

    public Page<Reaction> getAll(Pageable pageable) {
        return reactionRepository.findAll(pageable);
    }

    public Reaction getById(Long id) {
        return reactionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Reaction", id));
    }

    public List<Reaction> getReactionsByPatient(Long patientId) {
        return reactionRepository.findByPatientId(patientId);
    }

    public List<Reaction> getBySeverity(ReactionSeverity severity) {
        return reactionRepository.findBySeverity(severity);
    }

    public Reaction update(Long id, ReactionRequest req) {
        Reaction r = getById(id);
        if (req.getReactionType() != null) r.setReactionType(req.getReactionType());
        if (req.getSeverity() != null) r.setSeverity(req.getSeverity());
        if (req.getNotes() != null) r.setNotes(req.getNotes());
        return reactionRepository.save(r);
    }

    public Reaction updateStatus(Long id, ReactionStatus status) {
        Reaction r = getById(id);
        r.setStatus(status);
        return reactionRepository.save(r);
    }

    // --- LOOKBACK ---

    public LookbackTrace createTrace(LookbackRequest req) {
        LookbackTrace t = LookbackTrace.builder()
                .donationId(req.getDonationId())
                .componentId(req.getComponentId())
                .patientId(req.getPatientId())
                .traceDate(LocalDate.now())
                .status("ACTIVE")
                .build();
        return lookbackTraceRepository.save(t);
    }

    public List<LookbackTrace> getByDonation(Long donationId) {
        return lookbackTraceRepository.findByDonationId(donationId);
    }

    public List<LookbackTrace> getLookbackByPatient(Long patientId) {
        return lookbackTraceRepository.findByPatientId(patientId);
    }

    public List<LookbackTrace> getByComponent(Long componentId) {
        return lookbackTraceRepository.findByComponentId(componentId);
    }
}