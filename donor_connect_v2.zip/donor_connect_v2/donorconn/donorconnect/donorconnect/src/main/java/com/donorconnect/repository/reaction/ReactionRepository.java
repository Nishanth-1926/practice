package com.donorconnect.repository.reaction;

import com.donorconnect.entity.reaction.Reaction;
import com.donorconnect.enums.Enums.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ReactionRepository extends JpaRepository<Reaction, Long> {
    List<Reaction> findByPatientId(Long patientId);
    List<Reaction> findBySeverity(ReactionSeverity severity);
}
