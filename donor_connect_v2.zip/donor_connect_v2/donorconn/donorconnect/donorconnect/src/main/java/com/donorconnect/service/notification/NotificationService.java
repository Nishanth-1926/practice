package com.donorconnect.service.notification;

import com.donorconnect.dto.request.notification.NotificationRequest;
import com.donorconnect.entity.notification.Notification;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.exception.ResourceNotFoundException;
import com.donorconnect.repository.notification.NotificationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class NotificationService {

    private final NotificationRepository notificationRepository;

    public Notification create(NotificationRequest req) {
        Notification n = Notification.builder()
                .userId(req.getUserId())
                .message(req.getMessage())
                .category(req.getCategory())
                .status(NotificationStatus.UNREAD)
                .createdDate(LocalDateTime.now())
                .build();
        return notificationRepository.save(n);
    }

    public void createSystemNotification(Long userId, String message, NotificationCategory category) {
        Notification n = Notification.builder()
                .userId(userId)
                .message(message)
                .category(category)
                .status(NotificationStatus.UNREAD)
                .createdDate(LocalDateTime.now())
                .build();
        notificationRepository.save(n);
    }

    public List<Notification> getForUser(Long userId) {
        return notificationRepository.findByUserId(userId);
    }

    public Notification getById(Long id) {
        return notificationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notification", id));
    }

    public List<Notification> getUnreadForUser(Long userId) {
        return notificationRepository.findByUserIdAndStatus(userId, NotificationStatus.UNREAD);
    }

    public List<Notification> getByCategory(NotificationCategory category) {
        return notificationRepository.findByCategory(category);
    }

    public Notification markRead(Long id) {
        Notification n = getById(id);
        n.setStatus(NotificationStatus.READ);
        return notificationRepository.save(n);
    }

    public Notification dismiss(Long id) {
        Notification n = getById(id);
        n.setStatus(NotificationStatus.DISMISSED);
        return notificationRepository.save(n);
    }

    public void markAllReadForUser(Long userId) {
        List<Notification> unread = notificationRepository.findByUserIdAndStatus(userId, NotificationStatus.UNREAD);
        unread.forEach(n -> n.setStatus(NotificationStatus.READ));
        notificationRepository.saveAll(unread);
    }

    public void delete(Long id) {
        notificationRepository.deleteById(id);
    }
}
