package com.donorconnect.service.donor;

import com.donorconnect.dto.request.donor.DonorRequest;
import com.donorconnect.entity.collection.Donation;
import com.donorconnect.entity.donor.Donor;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.exception.ResourceNotFoundException;
import com.donorconnect.repository.collection.DonationRepository;
import com.donorconnect.repository.donor.DonorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DonorService {

    private final DonorRepository donorRepository;
    private final DonationRepository donationRepository;

    public Donor create(DonorRequest req) {
        Donor donor = Donor.builder()
            .name(req.getName()).dob(req.getDob()).gender(req.getGender())
            .bloodGroup(req.getBloodGroup()).rhFactor(req.getRhFactor())
            .contactInfo(req.getContactInfo()).addressJson(req.getAddressJson())
            .donorType(req.getDonorType()).status(DonorStatus.ACTIVE).build();
        return donorRepository.save(donor);
    }

    public Page<Donor> getAll(Pageable pageable) { return donorRepository.findAll(pageable); }

    public Donor getById(Long donorId) {
        return donorRepository.findById(donorId)
            .orElseThrow(() -> new ResourceNotFoundException("Donor", donorId));
    }

    public List<Donor> search(String name, String bloodGroup) {
        return donorRepository.searchDonors(name, bloodGroup);
    }

    public Donor update(Long donorId, DonorRequest req) {
        Donor donor = getById(donorId);
        if (req.getName() != null) donor.setName(req.getName());
        if (req.getDob() != null) donor.setDob(req.getDob());
        if (req.getGender() != null) donor.setGender(req.getGender());
        if (req.getBloodGroup() != null) donor.setBloodGroup(req.getBloodGroup());
        if (req.getRhFactor() != null) donor.setRhFactor(req.getRhFactor());
        if (req.getContactInfo() != null) donor.setContactInfo(req.getContactInfo());
        if (req.getAddressJson() != null) donor.setAddressJson(req.getAddressJson());
        if (req.getDonorType() != null) donor.setDonorType(req.getDonorType());
        return donorRepository.save(donor);
    }

    public Donor updateStatus(Long donorId, DonorStatus status) {
        Donor donor = getById(donorId);
        donor.setStatus(status);
        return donorRepository.save(donor);
    }

    public List<Donation> getDonationHistory(Long donorId) { return donationRepository.findByDonorId(donorId); }
    public List<Donor> getByBloodGroup(String bg) { return donorRepository.findByBloodGroup(bg); }
    public List<Donor> getByType(DonorType type) { return donorRepository.findByDonorType(type); }
}
