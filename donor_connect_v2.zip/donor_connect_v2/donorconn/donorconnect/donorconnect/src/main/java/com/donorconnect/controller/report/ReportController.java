package com.donorconnect.controller.report;

import com.donorconnect.dto.response.ApiResponse;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.service.report.ReportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/reports")
@RequiredArgsConstructor
@Tag(name = "Reports & Analytics", description = "KPIs, analytics and regulatory reports")
public class ReportController {

    private final ReportService reportService;

    @GetMapping("/inventory-snapshot")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Current stock by blood group x component")
    public ResponseEntity<ApiResponse<?>> inventorySnapshot() {
        return ResponseEntity.ok(ApiResponse.success(reportService.getInventorySnapshot()));
    }

    @GetMapping("/expiry-risk")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_INVENTORY_CONTROLLER')")
    @Operation(summary = "Components at expiry risk (next 7 days)")
    public ResponseEntity<ApiResponse<?>> expiryRisk() {
        return ResponseEntity.ok(ApiResponse.success(reportService.getExpiryRisk()));
    }

    @GetMapping("/donor-activity")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Active / lapsed donor counts")
    public ResponseEntity<ApiResponse<?>> donorActivity() {
        return ResponseEntity.ok(ApiResponse.success(reportService.getDonorActivity()));
    }

    @GetMapping("/donation-frequency")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Donations per period")
    public ResponseEntity<ApiResponse<?>> donationFrequency() {
        return ResponseEntity.ok(ApiResponse.success(reportService.getDonationFrequency()));
    }

    @GetMapping("/component-wastage")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Expired / disposed component stats")
    public ResponseEntity<ApiResponse<?>> componentWastage() {
        return ResponseEntity.ok(ApiResponse.success(reportService.getComponentWastage()));
    }

    @GetMapping("/reactive-count")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Reactive test result counts by type")
    public ResponseEntity<ApiResponse<?>> reactiveCount() {
        return ResponseEntity.ok(ApiResponse.success(reportService.getReactiveCount()));
    }

    @GetMapping("/deferrals")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Deferral trends")
    public ResponseEntity<ApiResponse<?>> deferrals() {
        return ResponseEntity.ok(ApiResponse.success(reportService.getDeferralTrends()));
    }

    @GetMapping("/tat")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Turnaround time: collection to release")
    public ResponseEntity<ApiResponse<?>> tat() {
        return ResponseEntity.ok(ApiResponse.success(reportService.getTAT()));
    }

    @GetMapping("/utilization")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Blood utilization report")
    public ResponseEntity<ApiResponse<?>> utilization() {
        return ResponseEntity.ok(ApiResponse.success(reportService.getUtilization()));
    }

    @PostMapping("/generate")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Manually trigger report generation")
    public ResponseEntity<ApiResponse<?>> generate(@RequestParam(defaultValue = "SITE") ReportScope scope) {
        return ResponseEntity.ok(ApiResponse.success("Report generated", reportService.generateReport(scope)));
    }

    @GetMapping("/{packId}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Get a saved report pack")
    public ResponseEntity<ApiResponse<?>> getPackById(@PathVariable Long packId) {
        return ResponseEntity.ok(ApiResponse.success(reportService.getPackById(packId)));
    }

    @GetMapping
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "All generated report packs")
    public ResponseEntity<ApiResponse<?>> getAllPacks(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(ApiResponse.success(reportService.getAllPacks(PageRequest.of(page, size))));
    }
}
