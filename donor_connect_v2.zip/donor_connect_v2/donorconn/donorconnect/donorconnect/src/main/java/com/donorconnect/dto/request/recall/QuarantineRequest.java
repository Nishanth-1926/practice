package com.donorconnect.dto.request.recall;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;

@Data
public class QuarantineRequest {
    @NotNull private Long componentId;
    private LocalDate startDate;
    @NotBlank private String reason;
}
