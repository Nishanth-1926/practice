package com.donorconnect.service.donor;

import com.donorconnect.dto.request.donor.DeferralRequest;
import com.donorconnect.entity.donor.Deferral;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.exception.PermanentDeferralException;
import com.donorconnect.exception.ResourceNotFoundException;
import com.donorconnect.repository.donor.DeferralRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DeferralService {

    private final DeferralRepository deferralRepo;

    public Deferral create(DeferralRequest req) {
        Deferral d = Deferral.builder().donorId(req.getDonorId()).deferralType(req.getDeferralType())
            .reason(req.getReason()).startDate(req.getStartDate()).endDate(req.getEndDate())
            .status(DeferralStatus.ACTIVE).build();
        return deferralRepo.save(d);
    }

    public Deferral getById(Long id) {
        return deferralRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Deferral", id));
    }

    public List<Deferral> getByDonor(Long donorId) { return deferralRepo.findByDonorId(donorId); }

    public Deferral update(Long id, DeferralRequest req) {
        Deferral d = getById(id);
        if (req.getReason() != null) d.setReason(req.getReason());
        if (req.getEndDate() != null) d.setEndDate(req.getEndDate());
        if (req.getDeferralType() != null) d.setDeferralType(req.getDeferralType());
        return deferralRepo.save(d);
    }

    public Deferral lift(Long id) {
        Deferral d = getById(id);
        if (d.getDeferralType() == DeferralType.PERMANENT)
            throw new PermanentDeferralException(id);
        d.setStatus(DeferralStatus.LIFTED);
        return deferralRepo.save(d);
    }

    public List<Deferral> getActive() { return deferralRepo.findByStatus(DeferralStatus.ACTIVE); }
}
