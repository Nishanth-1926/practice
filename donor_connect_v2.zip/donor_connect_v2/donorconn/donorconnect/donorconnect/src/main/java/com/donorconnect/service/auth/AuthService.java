package com.donorconnect.service.auth;

import com.donorconnect.dto.request.auth.*;
import com.donorconnect.entity.auth.AuditLog;
import com.donorconnect.entity.auth.User;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.exception.ResourceNotFoundException;
import com.donorconnect.exception.InvalidPasswordException;
import com.donorconnect.exception.UserAlreadyExistsException;
import com.donorconnect.repository.auth.AuditLogRepository;
import com.donorconnect.repository.auth.UserRepository;
import com.donorconnect.security.JwtTokenProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final AuditLogRepository auditLogRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider tokenProvider;

    private final Map<String, String> resetTokens = new HashMap<>();

    // --- AUTH ---

    public Map<String, String> login(LoginRequest req) {
        Authentication auth = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(req.getEmail(), req.getPassword()));
        String token = tokenProvider.generateToken(auth);
        User user = userRepository.findByEmail(req.getEmail()).orElseThrow();
        auditLogRepository.save(AuditLog.builder().userId(user.getUserId())
            .action("LOGIN").resource("AUTH").timestamp(LocalDateTime.now()).build());
        Map<String, String> result = new HashMap<>();
        result.put("token", token);
        result.put("role", user.getRole().name());
        result.put("email", user.getEmail());
        result.put("name", user.getName());
        return result;
    }

    public User register(RegisterRequest req) {
        if (userRepository.existsByEmail(req.getEmail()))
            throw new UserAlreadyExistsException(req.getEmail());
        User user = User.builder().name(req.getName()).email(req.getEmail()).phone(req.getPhone())
            .password(passwordEncoder.encode(req.getPassword())).role(req.getRole())
            .status(UserStatus.ACTIVE).build();
        return userRepository.save(user);
    }

    public void changePassword(String email, ChangePasswordRequest req) {
        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));
        if (!passwordEncoder.matches(req.getOldPassword(), user.getPassword()))
            throw new InvalidPasswordException("old password is incorrect");
        user.setPassword(passwordEncoder.encode(req.getNewPassword()));
        userRepository.save(user);
    }

    public String forgotPassword(String email) {
        userRepository.findByEmail(email)
            .orElseThrow(() -> new ResourceNotFoundException("User", "email", email));
        String token = UUID.randomUUID().toString();
        resetTokens.put(token, email);
        return "Reset token generated (in-app only for Phase-1). Token: " + token;
    }

    public String resetPassword(ResetPasswordRequest req) {
        User user = userRepository.findByEmail(req.getEmail())
            .orElseThrow(() -> new ResourceNotFoundException("User", "email", req.getEmail()));
        user.setPassword(passwordEncoder.encode(req.getNewPassword()));
        userRepository.save(user);
        return "Password reset successful";
    }

    // --- USER MANAGEMENT ---

    public Page<User> getAllUsers(Pageable pageable) { return userRepository.findAll(pageable); }

    public User getUserById(Long userId) {
        return userRepository.findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User", userId));
    }

    public List<User> getUsersByRole(UserRole role) { return userRepository.findByRole(role); }
    public List<User> getUsersByStatus(UserStatus status) { return userRepository.findByStatus(status); }

    public User updateUser(Long userId, UpdateUserRequest req) {
        User user = getUserById(userId);
        if (req.getName() != null) user.setName(req.getName());
        if (req.getPhone() != null) user.setPhone(req.getPhone());
        if (req.getRole() != null) user.setRole(req.getRole());
        return userRepository.save(user);
    }

    public void lockUser(Long userId) {
        User u = getUserById(userId); u.setStatus(UserStatus.LOCKED); userRepository.save(u);
    }
    public void unlockUser(Long userId) {
        User u = getUserById(userId); u.setStatus(UserStatus.ACTIVE); userRepository.save(u);
    }
    public void deactivateUser(Long userId) {
        User u = getUserById(userId); u.setStatus(UserStatus.INACTIVE); userRepository.save(u);
    }

    // --- AUDIT LOGS ---

    public Page<AuditLog> getAllAuditLogs(Pageable pageable) { return auditLogRepository.findAll(pageable); }
    public List<AuditLog> getAuditLogsByUser(Long userId) { return auditLogRepository.findByUserId(userId); }
    public List<AuditLog> getAuditLogsByAction(String action) { return auditLogRepository.findByAction(action); }
}
