package com.donorconnect.dto.request.donor;
import com.donorconnect.enums.Enums.*;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;

@Data
public class DeferralRequest {
    @NotNull private Long donorId;
    private DeferralType deferralType;
    private String reason;
    private LocalDate startDate;
    private LocalDate endDate;
}
