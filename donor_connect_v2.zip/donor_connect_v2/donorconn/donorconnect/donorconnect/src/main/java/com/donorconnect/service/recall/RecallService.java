package com.donorconnect.service.recall;

import com.donorconnect.dto.request.recall.DisposalRequest;
import com.donorconnect.dto.request.recall.QuarantineRequest;
import com.donorconnect.dto.request.recall.RecallRequest;
import com.donorconnect.entity.recall.DisposalRecord;
import com.donorconnect.entity.recall.QuarantineAction;
import com.donorconnect.entity.recall.RecallNotice;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.exception.ResourceNotFoundException;
import com.donorconnect.repository.recall.DisposalRecordRepository;
import com.donorconnect.repository.recall.QuarantineActionRepository;
import com.donorconnect.repository.recall.RecallNoticeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class RecallService {

    private final RecallNoticeRepository recallNoticeRepository;
    private final QuarantineActionRepository quarantineActionRepository;
    private final DisposalRecordRepository disposalRecordRepository;

    // --- RECALLS ---

    public RecallNotice createRecall(RecallRequest req) {
        RecallNotice r = RecallNotice.builder()
                .donationId(req.getDonationId())
                .componentId(req.getComponentId())
                .reason(req.getReason())
                .noticeDate(LocalDate.now())
                .status(RecallStatus.OPEN)
                .build();
        return recallNoticeRepository.save(r);
    }

    public Page<RecallNotice> getAllRecalls(Pageable pageable) {
        return recallNoticeRepository.findAll(pageable);
    }

    public RecallNotice getRecallById(Long id) {
        return recallNoticeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("RecallNotice", id));
    }

    public List<RecallNotice> getRecallsByDonation(Long donationId) {
        return recallNoticeRepository.findByDonationId(donationId);
    }

    public List<RecallNotice> getOpenRecalls() {
        return recallNoticeRepository.findByStatus(RecallStatus.OPEN);
    }

    public RecallNotice closeRecall(Long id) {
        RecallNotice r = getRecallById(id);
        r.setStatus(RecallStatus.CLOSED);
        return recallNoticeRepository.save(r);
    }

    // --- QUARANTINE ---

    public QuarantineAction quarantine(QuarantineRequest req) {
        QuarantineAction qa = QuarantineAction.builder()
                .componentId(req.getComponentId())
                .startDate(LocalDate.now())
                .reason(req.getReason())
                .status(QuarantineStatus.QUARANTINED)
                .build();
        return quarantineActionRepository.save(qa);
    }

    public Page<QuarantineAction> getAllQuarantine(Pageable pageable) {
        return quarantineActionRepository.findAll(pageable);
    }

    public QuarantineAction getQuarantineById(Long id) {
        return quarantineActionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("QuarantineAction", id));
    }

    public List<QuarantineAction> getByComponent(Long componentId) {
        return quarantineActionRepository.findByComponentId(componentId);
    }

    public List<QuarantineAction> getActiveQuarantine() {
        return quarantineActionRepository.findByStatus(QuarantineStatus.QUARANTINED);
    }

    public QuarantineAction release(Long id) {
        QuarantineAction qa = getQuarantineById(id);
        qa.setStatus(QuarantineStatus.RELEASED);
        qa.setReleasedDate(LocalDate.now());
        return quarantineActionRepository.save(qa);
    }

    // --- DISPOSAL ---

    public DisposalRecord createDisposal(DisposalRequest req) {
        DisposalRecord d = DisposalRecord.builder()
                .componentId(req.getComponentId())
                .disposalDate(LocalDate.now())
                .disposalReason(req.getDisposalReason())
                .witness(req.getWitness())
                .notes(req.getNotes())
                .status("COMPLETED")
                .build();
        return disposalRecordRepository.save(d);
    }

    public Page<DisposalRecord> getAllDisposals(Pageable pageable) {
        return disposalRecordRepository.findAll(pageable);
    }

    public DisposalRecord getDisposalById(Long id) {
        return disposalRecordRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("DisposalRecord", id));
    }

    public List<DisposalRecord> getDisposalsByComponent(Long componentId) {
        return disposalRecordRepository.findByComponentId(componentId);
    }
}
