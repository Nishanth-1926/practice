package com.donorconnect.service.donor;

import com.donorconnect.dto.request.donor.ScreeningRequest;
import com.donorconnect.entity.donor.ScreeningRecord;
import com.donorconnect.exception.ResourceNotFoundException;
import com.donorconnect.repository.donor.ScreeningRecordRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ScreeningService {

    private final ScreeningRecordRepository screeningRepo;

    public ScreeningRecord create(ScreeningRequest req) {
        ScreeningRecord record = ScreeningRecord.builder()
            .donorId(req.getDonorId()).screeningDate(req.getScreeningDate())
            .vitalsJson(req.getVitalsJson()).questionnaireJson(req.getQuestionnaireJson())
            .clearedFlag(req.getClearedFlag()).clearedBy(req.getClearedBy()).notes(req.getNotes())
            .build();
        return screeningRepo.save(record);
    }

    public ScreeningRecord getById(Long id) {
        return screeningRepo.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("ScreeningRecord", id));
    }

    public List<ScreeningRecord> getByDonor(Long donorId) { return screeningRepo.findByDonorId(donorId); }

    public ScreeningRecord update(Long id, ScreeningRequest req) {
        ScreeningRecord r = getById(id);
        if (req.getVitalsJson() != null) r.setVitalsJson(req.getVitalsJson());
        if (req.getQuestionnaireJson() != null) r.setQuestionnaireJson(req.getQuestionnaireJson());
        if (req.getClearedFlag() != null) r.setClearedFlag(req.getClearedFlag());
        if (req.getClearedBy() != null) r.setClearedBy(req.getClearedBy());
        if (req.getNotes() != null) r.setNotes(req.getNotes());
        return screeningRepo.save(r);
    }
}
