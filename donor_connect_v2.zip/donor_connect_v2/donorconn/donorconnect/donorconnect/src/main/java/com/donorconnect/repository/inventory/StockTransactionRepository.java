package com.donorconnect.repository.inventory;

import com.donorconnect.entity.inventory.StockTransaction;
import com.donorconnect.enums.Enums.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface StockTransactionRepository extends JpaRepository<StockTransaction, Long> {
    List<StockTransaction> findByComponentId(Long componentId);
    List<StockTransaction> findByTxnType(TransactionType txnType);
}
