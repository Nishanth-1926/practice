package com.donorconnect.dto.request.collection;
import com.donorconnect.enums.Enums.*;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;

@Data
public class TestResultRequest {
    @NotNull private Long donationId;
    private TestType testType;
    private String result;
    private LocalDate resultDate;
    private String enteredBy;
    private TestStatus status;
}
