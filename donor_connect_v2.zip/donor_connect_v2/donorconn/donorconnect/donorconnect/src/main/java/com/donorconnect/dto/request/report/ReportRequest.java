package com.donorconnect.dto.request.report;
import com.donorconnect.enums.Enums.*;
import lombok.Data;

@Data
public class ReportRequest {
    private ReportScope scope;
    private String period;
}
