package com.donorconnect.dto.request.billing;
import com.donorconnect.enums.Enums.*;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class BillingRequest {
    @NotNull private Long issueId;
    private BigDecimal chargeAmount;
    private ChargeType chargeType;
    private LocalDate billingDate;
}
