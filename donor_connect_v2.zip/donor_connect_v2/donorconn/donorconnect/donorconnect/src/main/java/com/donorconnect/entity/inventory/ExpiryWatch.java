package com.donorconnect.entity.inventory;

import com.donorconnect.enums.Enums.*;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "expiry_watch")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ExpiryWatch {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long expiryId;

    @Column(nullable = false)
    private Long componentId;

    private Integer daysToExpire;

    private LocalDate flagDate;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private ExpiryWatchStatus status = ExpiryWatchStatus.OPEN;
}
