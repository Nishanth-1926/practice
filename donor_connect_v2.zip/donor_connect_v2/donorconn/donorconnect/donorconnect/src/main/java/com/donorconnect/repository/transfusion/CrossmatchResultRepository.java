package com.donorconnect.repository.transfusion;

import com.donorconnect.entity.transfusion.CrossmatchResult;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CrossmatchResultRepository extends JpaRepository<CrossmatchResult, Long> {
    List<CrossmatchResult> findByRequestId(Long requestId);
}
