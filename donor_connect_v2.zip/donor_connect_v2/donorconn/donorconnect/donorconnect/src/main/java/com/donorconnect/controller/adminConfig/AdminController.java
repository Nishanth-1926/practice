package com.donorconnect.controller.adminConfig;

import com.donorconnect.dto.request.adminConfig.SystemConfigRequest;
import com.donorconnect.dto.response.ApiResponse;
import com.donorconnect.service.adminConfig.SystemConfigService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/admin/config")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ROLE_ADMIN')")
@Tag(name = "Admin Configuration", description = "System configuration management")
public class AdminController {

    private final SystemConfigService systemConfigService;

    @PostMapping
    @Operation(summary = "Create system config entry")
    public ResponseEntity<ApiResponse<?>> create(@RequestBody SystemConfigRequest request,
                                                  Authentication auth) {
        return ResponseEntity.ok(ApiResponse.success("Config created",
                systemConfigService.create(request, auth.getName())));
    }

    @GetMapping
    @Operation(summary = "Get all config entries")
    public ResponseEntity<ApiResponse<?>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(systemConfigService.getAll()));
    }

    @GetMapping("/{configId}")
    @Operation(summary = "Get config by ID")
    public ResponseEntity<ApiResponse<?>> getById(@PathVariable Long configId) {
        return ResponseEntity.ok(ApiResponse.success(systemConfigService.getById(configId)));
    }

    @GetMapping("/key/{key}")
    @Operation(summary = "Get config by key")
    public ResponseEntity<ApiResponse<?>> getByKey(@PathVariable String key) {
        return ResponseEntity.ok(ApiResponse.success(systemConfigService.getByKey(key)));
    }

    @PutMapping("/{configId}")
    @Operation(summary = "Update config entry")
    public ResponseEntity<ApiResponse<?>> update(@PathVariable Long configId,
                                                  @RequestBody SystemConfigRequest request,
                                                  Authentication auth) {
        return ResponseEntity.ok(ApiResponse.success("Config updated",
                systemConfigService.update(configId, request, auth.getName())));
    }

    @DeleteMapping("/{configId}")
    @Operation(summary = "Delete config entry")
    public ResponseEntity<ApiResponse<?>> delete(@PathVariable Long configId) {
        systemConfigService.delete(configId);
        return ResponseEntity.ok(ApiResponse.success("Config deleted", null));
    }
}
