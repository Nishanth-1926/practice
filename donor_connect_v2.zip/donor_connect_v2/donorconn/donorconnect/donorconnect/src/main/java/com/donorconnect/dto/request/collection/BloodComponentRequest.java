package com.donorconnect.dto.request.collection;

import com.donorconnect.enums.Enums.*;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;

@Data
public class BloodComponentRequest {
    @NotNull private Long donationId;
    @NotNull private ComponentType componentType;
    private String bagNumber;
    private Integer volume;
    private LocalDate manufactureDate;
    private LocalDate expiryDate;
}