package com.donorconnect.service.transfusion;

import com.donorconnect.dto.request.transfusion.CrossmatchRequestDto;
import com.donorconnect.dto.request.transfusion.CrossmatchResultRequest;
import com.donorconnect.dto.request.transfusion.IssueRequestDto;
import com.donorconnect.entity.transfusion.CrossmatchRequest;
import com.donorconnect.entity.transfusion.CrossmatchResult;
import com.donorconnect.entity.transfusion.IssueRecord;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.exception.ResourceNotFoundException;
import com.donorconnect.repository.transfusion.CrossmatchRequestRepository;
import com.donorconnect.repository.transfusion.CrossmatchResultRepository;
import com.donorconnect.repository.transfusion.IssueRecordRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TransfusionService {

    private final CrossmatchRequestRepository crossmatchRequestRepository;
    private final CrossmatchResultRepository crossmatchResultRepository;
    private final IssueRecordRepository issueRecordRepository;

    // --- CROSSMATCH REQUESTS ---

    public CrossmatchRequest createRequest(CrossmatchRequestDto req) {
        CrossmatchRequest r = CrossmatchRequest.builder()
                .patientId(req.getPatientId())
                .orderBy(req.getOrderBy())
                .bloodGroup(req.getBloodGroup())
                .rhFactor(req.getRhFactor())
                .requiredUnits(req.getRequiredUnits())
                .priority(req.getPriority() != null ? req.getPriority() : CrossmatchPriority.ROUTINE)
                .requestDate(LocalDate.now())
                .status(CrossmatchStatus.PENDING)
                .build();
        return crossmatchRequestRepository.save(r);
    }

    public Page<CrossmatchRequest> getAllRequests(Pageable pageable) {
        return crossmatchRequestRepository.findAll(pageable);
    }

    public CrossmatchRequest getRequestById(Long id) {
        return crossmatchRequestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("CrossmatchRequest", id));
    }

    public List<CrossmatchRequest> getRequestsByPatient(Long patientId) {
        return crossmatchRequestRepository.findByPatientId(patientId);
    }

    public List<CrossmatchRequest> getPendingRequests() {
        return crossmatchRequestRepository.findByStatus(CrossmatchStatus.PENDING);
    }

    public CrossmatchRequest updateRequestStatus(Long id, CrossmatchStatus status) {
        CrossmatchRequest r = getRequestById(id);
        r.setStatus(status);
        return crossmatchRequestRepository.save(r);
    }

    // --- CROSSMATCH RESULTS ---

    public CrossmatchResult createResult(CrossmatchResultRequest req) {
        CrossmatchResult r = CrossmatchResult.builder()
                .requestId(req.getRequestId())
                .componentId(req.getComponentId())
                .compatibility(req.getCompatibility())
                .testedBy(req.getTestedBy())
                .testedDate(LocalDate.now())
                .status(req.getCompatibility() == Compatibility.COMPATIBLE
                        ? CrossmatchStatus.MATCHED : CrossmatchStatus.REJECTED)
                .build();
        CrossmatchResult saved = crossmatchResultRepository.save(r);

        // auto-update request status
        CrossmatchRequest request = getRequestById(req.getRequestId());
        if (req.getCompatibility() == Compatibility.COMPATIBLE) {
            request.setStatus(CrossmatchStatus.MATCHED);
            crossmatchRequestRepository.save(request);
        }
        return saved;
    }

    public CrossmatchResult getResultById(Long id) {
        return crossmatchResultRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("CrossmatchResult", id));
    }

    public List<CrossmatchResult> getResultsByRequest(Long requestId) {
        return crossmatchResultRepository.findByRequestId(requestId);
    }

    // --- ISSUE ---

    public IssueRecord issue(IssueRequestDto req) {
        IssueRecord r = IssueRecord.builder()
                .componentId(req.getComponentId())
                .patientId(req.getPatientId())
                .issueDate(LocalDate.now())
                .issuedBy(req.getIssuedBy())
                .indication(req.getIndication())
                .status(IssueStatus.ISSUED)
                .build();
        return issueRecordRepository.save(r);
    }

    public Page<IssueRecord> getAllIssues(Pageable pageable) {
        return issueRecordRepository.findAll(pageable);
    }

    public IssueRecord getIssueById(Long id) {
        return issueRecordRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("IssueRecord", id));
    }

    public List<IssueRecord> getIssuesByPatient(Long patientId) {
        return issueRecordRepository.findByPatientId(patientId);
    }

    public List<IssueRecord> getIssuesByComponent(Long componentId) {
        return issueRecordRepository.findByComponentId(componentId);
    }

    public IssueRecord returnUnit(Long id) {
        IssueRecord r = getIssueById(id);
        r.setStatus(IssueStatus.RETURNED);
        return issueRecordRepository.save(r);
    }
}
