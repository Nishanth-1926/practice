package com.donorconnect.entity.billing;

import com.donorconnect.enums.Enums.*;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "billing_refs")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BillingRef {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long billingId;

    @Column(nullable = false)
    private Long issueId;

    private BigDecimal chargeAmount;

    @Enumerated(EnumType.STRING)
    private ChargeType chargeType;

    private LocalDate billingDate;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private BillingStatus status = BillingStatus.PENDING;
}
