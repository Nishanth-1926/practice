package com.donorconnect.service.collection;

import com.donorconnect.dto.request.collection.DonationRequest;
import com.donorconnect.entity.collection.Donation;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.exception.ResourceNotFoundException;
import com.donorconnect.repository.collection.DonationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DonationService {

    private final DonationRepository donationRepository;

    public Donation create(DonationRequest req) {
        Donation d = Donation.builder()
                .donorId(req.getDonorId())
                .collectionDate(req.getCollectionDate() != null ? req.getCollectionDate() : LocalDate.now())
                .bagId(req.getBagId())
                .volumeMl(req.getVolumeMl())
                .collectedBy(req.getCollectedBy())
                .collectionStatus(CollectionStatus.COLLECTED)
                .build();
        return donationRepository.save(d);
    }

    public Page<Donation> getAll(Pageable pageable) {
        return donationRepository.findAll(pageable);
    }

    public Donation getById(Long id) {
        return donationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Donation", id));
    }

    public List<Donation> getByDonor(Long donorId) {
        return donationRepository.findByDonorId(donorId);
    }

    public Donation update(Long id, DonationRequest req) {
        Donation d = getById(id);
        if (req.getVolumeMl() != null) d.setVolumeMl(req.getVolumeMl());
        if (req.getCollectedBy() != null) d.setCollectedBy(req.getCollectedBy());
        return donationRepository.save(d);
    }

    public Donation updateStatus(Long id, CollectionStatus status) {
        Donation d = getById(id);
        d.setCollectionStatus(status);
        return donationRepository.save(d);
    }

    public Donation getByBagId(String bagId) {
        return donationRepository.findByBagId(bagId)
                .orElseThrow(() -> new RuntimeException("Donation not found for bag: " + bagId));
    }
}
