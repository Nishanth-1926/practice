package com.donorconnect.controller.inventory;

import com.donorconnect.dto.request.inventory.StockTransactionRequest;
import com.donorconnect.dto.response.ApiResponse;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.service.inventory.InventoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@Tag(name = "Inventory", description = "Blood inventory, stock transactions and expiry watch")
public class InventoryController {

    private final InventoryService inventoryService;

    // --- INVENTORY BALANCE ---

    @GetMapping("/api/v1/inventory")
    @PreAuthorize("hasAnyRole('ROLE_INVENTORY_CONTROLLER','ROLE_ADMIN')")
    @Operation(summary = "Full inventory snapshot")
    public ResponseEntity<ApiResponse<?>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(inventoryService.getAll()));
    }

    @GetMapping("/api/v1/inventory/blood-group/{bloodGroup}")
    @PreAuthorize("hasAnyRole('ROLE_INVENTORY_CONTROLLER','ROLE_ADMIN')")
    @Operation(summary = "Stock by blood group")
    public ResponseEntity<ApiResponse<?>> getByBloodGroup(@PathVariable String bloodGroup) {
        return ResponseEntity.ok(ApiResponse.success(inventoryService.getByBloodGroup(bloodGroup)));
    }

    @GetMapping("/api/v1/inventory/low-stock")
    @PreAuthorize("hasAnyRole('ROLE_INVENTORY_CONTROLLER','ROLE_ADMIN')")
    @Operation(summary = "Items below threshold")
    public ResponseEntity<ApiResponse<?>> getLowStock() {
        return ResponseEntity.ok(ApiResponse.success(inventoryService.getLowStock()));
    }

    @GetMapping("/api/v1/inventory/summary")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_TRANSFUSION_OFFICER')")
    @Operation(summary = "Summary grid (blood group x component)")
    public ResponseEntity<ApiResponse<?>> getSummary() {
        return ResponseEntity.ok(ApiResponse.success(inventoryService.getSummary()));
    }

    // --- STOCK TRANSACTIONS ---

    @PostMapping("/api/v1/stock-transactions")
    @PreAuthorize("hasAnyRole('ROLE_INVENTORY_CONTROLLER','ROLE_ADMIN')")
    @Operation(summary = "Record stock transaction")
    public ResponseEntity<ApiResponse<?>> createTransaction(@RequestBody StockTransactionRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Transaction recorded", inventoryService.createTransaction(request)));
    }

    @GetMapping("/api/v1/stock-transactions")
    @PreAuthorize("hasAnyRole('ROLE_INVENTORY_CONTROLLER','ROLE_ADMIN')")
    @Operation(summary = "All transactions (paginated)")
    public ResponseEntity<ApiResponse<?>> getAllTransactions(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(ApiResponse.success(inventoryService.getAllTransactions(PageRequest.of(page, size))));
    }

    @GetMapping("/api/v1/stock-transactions/{txnId}")
    @PreAuthorize("hasAnyRole('ROLE_INVENTORY_CONTROLLER','ROLE_ADMIN')")
    @Operation(summary = "Get transaction by ID")
    public ResponseEntity<ApiResponse<?>> getTransactionById(@PathVariable Long txnId) {
        return ResponseEntity.ok(ApiResponse.success(inventoryService.getTransactionById(txnId)));
    }

    @GetMapping("/api/v1/stock-transactions/component/{componentId}")
    @PreAuthorize("hasAnyRole('ROLE_INVENTORY_CONTROLLER','ROLE_ADMIN')")
    @Operation(summary = "Transactions for a component")
    public ResponseEntity<ApiResponse<?>> getByComponent(@PathVariable Long componentId) {
        return ResponseEntity.ok(ApiResponse.success(inventoryService.getTransactionsByComponent(componentId)));
    }

    @GetMapping("/api/v1/stock-transactions/type/{txnType}")
    @PreAuthorize("hasAnyRole('ROLE_INVENTORY_CONTROLLER','ROLE_ADMIN')")
    @Operation(summary = "Filter by transaction type")
    public ResponseEntity<ApiResponse<?>> getByType(@PathVariable TransactionType txnType) {
        return ResponseEntity.ok(ApiResponse.success(inventoryService.getTransactionsByType(txnType)));
    }

    // --- EXPIRY WATCH ---

    @GetMapping("/api/v1/expiry-watch")
    @PreAuthorize("hasAnyRole('ROLE_INVENTORY_CONTROLLER','ROLE_ADMIN')")
    @Operation(summary = "All expiry watch records")
    public ResponseEntity<ApiResponse<?>> getAllExpiryWatch() {
        return ResponseEntity.ok(ApiResponse.success(inventoryService.getAllExpiryWatch()));
    }

    @GetMapping("/api/v1/expiry-watch/open")
    @PreAuthorize("hasAnyRole('ROLE_INVENTORY_CONTROLLER','ROLE_ADMIN')")
    @Operation(summary = "Unactioned expiry alerts")
    public ResponseEntity<ApiResponse<?>> getOpenExpiryWatch() {
        return ResponseEntity.ok(ApiResponse.success(inventoryService.getOpenExpiryWatch()));
    }

    @PatchMapping("/api/v1/expiry-watch/{expiryId}/action")
    @PreAuthorize("hasAnyRole('ROLE_INVENTORY_CONTROLLER','ROLE_ADMIN')")
    @Operation(summary = "Mark expiry alert as actioned")
    public ResponseEntity<ApiResponse<?>> actionExpiryWatch(@PathVariable Long expiryId) {
        return ResponseEntity.ok(ApiResponse.success("Expiry watch actioned", inventoryService.actionExpiryWatch(expiryId)));
    }
}
