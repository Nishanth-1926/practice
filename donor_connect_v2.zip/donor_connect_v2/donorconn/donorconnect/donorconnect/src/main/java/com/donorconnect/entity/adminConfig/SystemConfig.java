package com.donorconnect.entity.adminConfig;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "system_configs")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SystemConfig {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long configId;

    @Column(nullable = false, unique = true)
    private String key;

    @Column(columnDefinition = "TEXT")
    private String value;

    @Builder.Default
    private String scope = "GLOBAL";

    private String updatedBy;

    @Builder.Default
    private LocalDateTime updatedDate = LocalDateTime.now();
}
