package com.donorconnect.service.inventory;

import com.donorconnect.dto.request.inventory.StockTransactionRequest;
import com.donorconnect.entity.inventory.ExpiryWatch;
import com.donorconnect.entity.inventory.InventoryBalance;
import com.donorconnect.entity.inventory.StockTransaction;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.exception.ResourceNotFoundException;
import com.donorconnect.exception.InsufficientStockException;
import com.donorconnect.repository.inventory.ExpiryWatchRepository;
import com.donorconnect.repository.inventory.InventoryBalanceRepository;
import com.donorconnect.repository.inventory.StockTransactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class InventoryService {

    private final InventoryBalanceRepository inventoryBalanceRepository;
    private final StockTransactionRepository stockTransactionRepository;
    private final ExpiryWatchRepository expiryWatchRepository;

    public List<InventoryBalance> getAll() { return inventoryBalanceRepository.findAll(); }

    public List<InventoryBalance> getByBloodGroup(String bloodGroup) {
        return inventoryBalanceRepository.findByBloodGroup(bloodGroup);
    }

    public List<InventoryBalance> getLowStock() {
        return inventoryBalanceRepository.findByQuantityLessThan(5);
    }

    public List<InventoryBalance> getSummary() { return inventoryBalanceRepository.findAll(); }

    public StockTransaction createTransaction(StockTransactionRequest req) {
        StockTransaction t = StockTransaction.builder()
                .componentId(req.getComponentId()).locationId(req.getLocationId())
                .txnType(req.getTxnType()).quantity(req.getQuantity())
                .txnDate(req.getTxnDate() != null ? req.getTxnDate() : LocalDate.now())
                .referenceId(req.getReferenceId()).notes(req.getNotes()).build();
        StockTransaction saved = stockTransactionRepository.save(t);

        List<InventoryBalance> balances = inventoryBalanceRepository.findAll().stream()
                .filter(b -> b.getComponentId().equals(req.getComponentId())).toList();

        if (balances.isEmpty()) {
            InventoryBalance balance = InventoryBalance.builder()
                    .componentId(req.getComponentId()).locationId(req.getLocationId())
                    .quantity(req.getQuantity()).status(ComponentStatus.AVAILABLE).build();
            inventoryBalanceRepository.save(balance);
        } else {
            InventoryBalance balance = balances.get(0);
            if (req.getTxnType() == TransactionType.ISSUE || req.getTxnType() == TransactionType.TRANSFER_OUT) {
                if (balance.getQuantity() < req.getQuantity()) {
                    throw new InsufficientStockException(req.getComponentId(), req.getQuantity(), balance.getQuantity());
                }
                balance.setQuantity(Math.max(0, balance.getQuantity() - req.getQuantity()));
            } else {
                balance.setQuantity(balance.getQuantity() + req.getQuantity());
            }
            inventoryBalanceRepository.save(balance);
        }
        return saved;
    }

    public Page<StockTransaction> getAllTransactions(Pageable pageable) {
        return stockTransactionRepository.findAll(pageable);
    }

    public StockTransaction getTransactionById(Long id) {
        return stockTransactionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("StockTransaction", id));
    }

    public List<StockTransaction> getTransactionsByComponent(Long componentId) {
        return stockTransactionRepository.findByComponentId(componentId);
    }

    public List<StockTransaction> getTransactionsByType(TransactionType type) {
        return stockTransactionRepository.findByTxnType(type);
    }

    public List<ExpiryWatch> getAllExpiryWatch() { return expiryWatchRepository.findAll(); }

    public List<ExpiryWatch> getOpenExpiryWatch() {
        return expiryWatchRepository.findByStatus(ExpiryWatchStatus.OPEN);
    }

    public ExpiryWatch actionExpiryWatch(Long expiryId) {
        ExpiryWatch ew = expiryWatchRepository.findById(expiryId)
                .orElseThrow(() -> new ResourceNotFoundException("ExpiryWatch", expiryId));
        ew.setStatus(ExpiryWatchStatus.ACTIONED);
        return expiryWatchRepository.save(ew);
    }

    public void createExpiryWatch(Long componentId, int daysToExpire) {
        if (!expiryWatchRepository.existsByComponentIdAndStatus(componentId, ExpiryWatchStatus.OPEN)) {
            ExpiryWatch ew = ExpiryWatch.builder().componentId(componentId).daysToExpire(daysToExpire)
                    .flagDate(LocalDate.now()).status(ExpiryWatchStatus.OPEN).build();
            expiryWatchRepository.save(ew);
        }
    }
}