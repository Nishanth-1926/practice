package com.donorconnect.dto.request.reaction;
import com.donorconnect.enums.Enums.*;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;

@Data
public class ReactionRequest {
    @NotNull private Long issueId;
    @NotNull private Long patientId;
    private String reactionType;
    private ReactionSeverity severity;
    private LocalDate reactionDate;
    private String notes;
}
