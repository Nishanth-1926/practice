package com.donorconnect.service.appointment;

import com.donorconnect.dto.request.appointment.AppointmentRequest;
import com.donorconnect.entity.appointment.DonationAppointment;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.repository.appointment.DonationAppointmentRepository;
import com.donorconnect.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AppointmentService {

    private final DonationAppointmentRepository appointmentRepository;

    public DonationAppointment book(AppointmentRequest req) {
        DonationAppointment a = DonationAppointment.builder()
                .donorId(req.getDonorId())
                .dateTime(req.getDateTime())
                .centerId(req.getCenterId())
                .driveId(req.getDriveId())
                .status(AppointmentStatus.BOOKED)
                .build();
        return appointmentRepository.save(a);
    }

    public Page<DonationAppointment> getAll(Pageable pageable) {
        return appointmentRepository.findAll(pageable);
    }

    public DonationAppointment getById(Long id) {
        return appointmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Appointment", id));
    }

    public List<DonationAppointment> getByDonor(Long donorId) {
        return appointmentRepository.findByDonorId(donorId);
    }

    public List<DonationAppointment> getToday() {
        LocalDateTime start = LocalDateTime.now().toLocalDate().atStartOfDay();
        LocalDateTime end = start.plusDays(1);
        return appointmentRepository.findByDateTimeBetween(start, end);
    }

    public DonationAppointment update(Long id, AppointmentRequest req) {
        DonationAppointment a = getById(id);
        if (req.getDateTime() != null) a.setDateTime(req.getDateTime());
        if (req.getCenterId() != null) a.setCenterId(req.getCenterId());
        return appointmentRepository.save(a);
    }

    public DonationAppointment updateStatus(Long id, AppointmentStatus status) {
        DonationAppointment a = getById(id);
        a.setStatus(status);
        return appointmentRepository.save(a);
    }
}
