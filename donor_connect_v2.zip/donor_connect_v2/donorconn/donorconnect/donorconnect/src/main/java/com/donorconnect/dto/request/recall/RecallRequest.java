package com.donorconnect.dto.request.recall;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;

@Data
public class RecallRequest {
    private Long donationId;
    private Long componentId;
    @NotBlank private String reason;
    private LocalDate noticeDate;
}
