package com.donorconnect.entity.inventory;

import com.donorconnect.enums.Enums.*;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "inventory_balances")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InventoryBalance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long balanceId;

    private Long componentId;

    private String bloodGroup;

    private String rhFactor;

    private Long locationId;

    @Builder.Default
    private Integer quantity = 0;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private ComponentStatus status = ComponentStatus.AVAILABLE;
}
