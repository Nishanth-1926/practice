package com.donorconnect.dto.request.reaction;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;

@Data
public class LookbackRequest {
    @NotNull private Long donationId;
    @NotNull private Long componentId;
    @NotNull private Long patientId;
    private LocalDate traceDate;
}
