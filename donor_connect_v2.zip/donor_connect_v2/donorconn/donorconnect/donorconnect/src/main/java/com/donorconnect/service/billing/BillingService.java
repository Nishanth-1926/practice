package com.donorconnect.service.billing;

import com.donorconnect.dto.request.billing.BillingRequest;
import com.donorconnect.entity.billing.BillingRef;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.exception.ResourceNotFoundException;
import com.donorconnect.repository.billing.BillingRefRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class BillingService {

    private final BillingRefRepository billingRefRepository;

    public BillingRef create(BillingRequest req) {
        BillingRef b = BillingRef.builder()
                .issueId(req.getIssueId())
                .chargeAmount(req.getChargeAmount())
                .chargeType(req.getChargeType())
                .billingDate(LocalDate.now())
                .status(BillingStatus.PENDING)
                .build();
        return billingRefRepository.save(b);
    }

    public Page<BillingRef> getAll(Pageable pageable) {
        return billingRefRepository.findAll(pageable);
    }

    public BillingRef getById(Long id) {
        return billingRefRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("BillingRecord",  id));
    }

    public BillingRef getByIssue(Long issueId) {
        return billingRefRepository.findByIssueId(issueId)
                .orElseThrow(() -> new ResourceNotFoundException("BillingRecord", "issueId", issueId));
    }

    public List<BillingRef> exportByDateRange(LocalDate from, LocalDate to) {
        return billingRefRepository.findByBillingDateBetween(from, to);
    }

    public BillingRef updateStatus(Long id, BillingStatus status) {
        BillingRef b = getById(id);
        b.setStatus(status);
        return billingRefRepository.save(b);
    }
}
