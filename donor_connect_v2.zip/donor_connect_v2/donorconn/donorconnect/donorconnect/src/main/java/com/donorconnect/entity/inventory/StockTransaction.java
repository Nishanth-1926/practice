package com.donorconnect.entity.inventory;

import com.donorconnect.enums.Enums.*;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "stock_transactions")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StockTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long txnId;

    @Column(nullable = false)
    private Long componentId;

    private Long locationId;

    @Enumerated(EnumType.STRING)
    private TransactionType txnType;

    private Integer quantity;

    private LocalDate txnDate;

    private Long referenceId;

    @Column(columnDefinition = "TEXT")
    private String notes;
}
