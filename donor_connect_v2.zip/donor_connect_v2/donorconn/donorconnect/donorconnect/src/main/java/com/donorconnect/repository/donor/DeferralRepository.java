package com.donorconnect.repository.donor;

import com.donorconnect.entity.donor.Deferral;
import com.donorconnect.enums.Enums.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface DeferralRepository extends JpaRepository<Deferral, Long> {
    List<Deferral> findByDonorId(Long donorId);
    List<Deferral> findByStatus(DeferralStatus status);
}
