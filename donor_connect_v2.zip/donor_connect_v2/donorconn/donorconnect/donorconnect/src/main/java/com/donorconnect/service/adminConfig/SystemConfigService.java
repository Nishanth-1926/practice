package com.donorconnect.service.adminConfig;

import com.donorconnect.dto.request.adminConfig.SystemConfigRequest;
import com.donorconnect.entity.adminConfig.SystemConfig;
import com.donorconnect.exception.ResourceNotFoundException;
import com.donorconnect.repository.adminConfig.SystemConfigRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class SystemConfigService {

    private final SystemConfigRepository systemConfigRepository;

    public SystemConfig create(SystemConfigRequest req, String updatedBy) {
        SystemConfig cfg = SystemConfig.builder()
                .key(req.getKey())
                .value(req.getValue())
                .scope(req.getScope() != null ? req.getScope() : "GLOBAL")
                .updatedBy(updatedBy)
                .updatedDate(LocalDateTime.now())
                .build();
        return systemConfigRepository.save(cfg);
    }

    public List<SystemConfig> getAll() {
        return systemConfigRepository.findAll();
    }

    public SystemConfig getById(Long id) {
        return systemConfigRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("SystemConfig", id));
    }

    public SystemConfig getByKey(String key) {
        return systemConfigRepository.findByKey(key)
                .orElseThrow(() -> new ResourceNotFoundException("SystemConfig", "key", key));
    }

    public SystemConfig update(Long id, SystemConfigRequest req, String updatedBy) {
        SystemConfig cfg = getById(id);
        if (req.getValue() != null) cfg.setValue(req.getValue());
        if (req.getScope() != null) cfg.setScope(req.getScope());
        cfg.setUpdatedBy(updatedBy);
        cfg.setUpdatedDate(LocalDateTime.now());
        return systemConfigRepository.save(cfg);
    }

    public void delete(Long id) {
        systemConfigRepository.deleteById(id);
    }
}
