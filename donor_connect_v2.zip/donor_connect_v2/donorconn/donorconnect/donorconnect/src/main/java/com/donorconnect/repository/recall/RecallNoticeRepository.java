package com.donorconnect.repository.recall;

import com.donorconnect.entity.recall.RecallNotice;
import com.donorconnect.enums.Enums.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface RecallNoticeRepository extends JpaRepository<RecallNotice, Long> {
    List<RecallNotice> findByDonationId(Long donationId);
    List<RecallNotice> findByStatus(RecallStatus status);
}
