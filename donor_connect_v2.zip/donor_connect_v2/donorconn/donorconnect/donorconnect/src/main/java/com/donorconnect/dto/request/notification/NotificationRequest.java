package com.donorconnect.dto.request.notification;
import com.donorconnect.enums.Enums.*;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class NotificationRequest {
    @NotNull private Long userId;
    @NotBlank private String message;
    private NotificationCategory category;
}
