package com.donorconnect.entity.report;

import com.donorconnect.enums.Enums.*;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "lab_report_packs")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LabReportPack {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long packId;

    @Enumerated(EnumType.STRING)
    private ReportScope scope;

    @Column(columnDefinition = "TEXT")
    private String metricsJson;

    @Builder.Default
    private LocalDateTime generatedDate = LocalDateTime.now();
}
