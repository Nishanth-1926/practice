package com.donorconnect.dto.request.donor;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;

@Data
public class ScreeningRequest {
    @NotNull private Long donorId;
    private LocalDate screeningDate;
    private String vitalsJson;
    private String questionnaireJson;
    private Boolean clearedFlag;
    private String clearedBy;
    private String notes;
}
