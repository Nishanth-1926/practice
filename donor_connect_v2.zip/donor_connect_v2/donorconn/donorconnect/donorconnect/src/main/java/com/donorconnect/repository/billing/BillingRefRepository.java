package com.donorconnect.repository.billing;

import com.donorconnect.entity.billing.BillingRef;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface BillingRefRepository extends JpaRepository<BillingRef, Long> {
    Optional<BillingRef> findByIssueId(Long issueId);
    List<BillingRef> findByBillingDateBetween(LocalDate from, LocalDate to);
}
