package com.donorconnect.repository.donor;

import com.donorconnect.entity.donor.ScreeningRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ScreeningRecordRepository extends JpaRepository<ScreeningRecord, Long> {
    List<ScreeningRecord> findByDonorId(Long donorId);
}
