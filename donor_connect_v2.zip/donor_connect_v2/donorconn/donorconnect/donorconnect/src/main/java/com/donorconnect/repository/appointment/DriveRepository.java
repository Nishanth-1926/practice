package com.donorconnect.repository.appointment;

import com.donorconnect.entity.appointment.Drive;
import com.donorconnect.enums.Enums.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface DriveRepository extends JpaRepository<Drive, Long> {
    List<Drive> findByScheduledDateAfter(LocalDate date);
    List<Drive> findByStatus(DriveStatus status);
}
