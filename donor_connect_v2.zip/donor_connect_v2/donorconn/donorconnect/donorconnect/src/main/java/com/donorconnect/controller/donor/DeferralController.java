package com.donorconnect.controller.donor;

import com.donorconnect.dto.request.donor.DeferralRequest;
import com.donorconnect.dto.response.ApiResponse;
import com.donorconnect.service.donor.DeferralService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/deferrals")
@RequiredArgsConstructor
@Tag(name = "Deferrals", description = "Donor deferral management")
public class DeferralController {

    private final DeferralService deferralService;

    @PostMapping
    @PreAuthorize("hasAnyRole('ROLE_RECEPTION','ROLE_ADMIN')")
    @Operation(summary = "Create deferral")
    public ResponseEntity<ApiResponse<?>> create(@RequestBody DeferralRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Deferral created", deferralService.create(request)));
    }

    @GetMapping("/{deferralId}")
    @PreAuthorize("hasAnyRole('ROLE_RECEPTION','ROLE_ADMIN')")
    @Operation(summary = "Get deferral by ID")
    public ResponseEntity<ApiResponse<?>> getById(@PathVariable Long deferralId) {
        return ResponseEntity.ok(ApiResponse.success(deferralService.getById(deferralId)));
    }

    @GetMapping("/donor/{donorId}")
    @PreAuthorize("hasAnyRole('ROLE_RECEPTION','ROLE_ADMIN')")
    @Operation(summary = "All deferrals for a donor")
    public ResponseEntity<ApiResponse<?>> getByDonor(@PathVariable Long donorId) {
        return ResponseEntity.ok(ApiResponse.success(deferralService.getByDonor(donorId)));
    }

    @PutMapping("/{deferralId}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Update deferral")
    public ResponseEntity<ApiResponse<?>> update(@PathVariable Long deferralId,
                                                  @RequestBody DeferralRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Deferral updated", deferralService.update(deferralId, request)));
    }

    @PatchMapping("/{deferralId}/lift")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Lift a temporary deferral")
    public ResponseEntity<ApiResponse<?>> lift(@PathVariable Long deferralId) {
        return ResponseEntity.ok(ApiResponse.success("Deferral lifted", deferralService.lift(deferralId)));
    }

    @GetMapping("/active")
    @PreAuthorize("hasAnyRole('ROLE_RECEPTION','ROLE_ADMIN')")
    @Operation(summary = "All currently active deferrals")
    public ResponseEntity<ApiResponse<?>> getActive() {
        return ResponseEntity.ok(ApiResponse.success(deferralService.getActive()));
    }
}
