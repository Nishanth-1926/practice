package com.donorconnect.repository.recall;

import com.donorconnect.entity.recall.QuarantineAction;
import com.donorconnect.enums.Enums.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface QuarantineActionRepository extends JpaRepository<QuarantineAction, Long> {
    List<QuarantineAction> findByComponentId(Long componentId);
    List<QuarantineAction> findByStatus(QuarantineStatus status);
}
