package com.donorconnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class DonorConnectApplication {
    public static void main(String[] args) {
        SpringApplication.run(DonorConnectApplication.class, args);
    }
}
