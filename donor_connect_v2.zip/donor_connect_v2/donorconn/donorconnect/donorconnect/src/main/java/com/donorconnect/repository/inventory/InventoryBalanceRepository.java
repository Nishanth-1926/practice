package com.donorconnect.repository.inventory;

import com.donorconnect.entity.inventory.InventoryBalance;
import com.donorconnect.enums.Enums.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface InventoryBalanceRepository extends JpaRepository<InventoryBalance, Long> {
    List<InventoryBalance> findByBloodGroup(String bloodGroup);
    List<InventoryBalance> findByStatus(ComponentStatus status);
    List<InventoryBalance> findByQuantityLessThan(int threshold);
}
