package com.donorconnect.dto.request.transfusion;
import com.donorconnect.enums.Enums.*;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;

@Data
public class CrossmatchResultRequest {
    @NotNull private Long requestId;
    @NotNull private Long componentId;
    private Compatibility compatibility;
    private String testedBy;
    private LocalDate testedDate;
}
