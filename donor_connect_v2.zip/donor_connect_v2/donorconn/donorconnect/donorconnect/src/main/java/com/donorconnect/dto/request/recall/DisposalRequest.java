package com.donorconnect.dto.request.recall;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;

@Data
public class DisposalRequest {
    @NotNull private Long componentId;
    private LocalDate disposalDate;
    private String disposalReason;
    private String witness;
    private String notes;
}
