package com.donorconnect.dto.request.auth;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class ResetPasswordRequest {
    @NotBlank private String email;
    private String token;
    @NotBlank @Size(min=6) private String newPassword;
}
