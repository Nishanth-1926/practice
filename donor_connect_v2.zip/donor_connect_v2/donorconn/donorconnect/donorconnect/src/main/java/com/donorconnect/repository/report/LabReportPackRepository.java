package com.donorconnect.repository.report;

import com.donorconnect.entity.report.LabReportPack;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LabReportPackRepository extends JpaRepository<LabReportPack, Long> {}
