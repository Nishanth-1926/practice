package com.donorconnect.scheduler;

import com.donorconnect.entity.collection.BloodComponent;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.repository.collection.BloodComponentRepository;
import com.donorconnect.service.inventory.InventoryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class ExpiryWatchScheduler {

    private final BloodComponentRepository bloodComponentRepository;
    private final InventoryService inventoryService;

    @Value("${app.expiry.warning-days:3}")
    private int warningDays;

    @Scheduled(cron = "0 0 6 * * *")
    public void scanExpiringComponents() {
        log.info("Running expiry watch scan...");

        LocalDate threshold = LocalDate.now().plusDays(warningDays);
        List<BloodComponent> expiring = bloodComponentRepository.findByExpiryDateBetween(LocalDate.now(), threshold);

        for (BloodComponent c : expiring) {
            if (c.getStatus() == ComponentStatus.AVAILABLE) {
                long daysLeft = ChronoUnit.DAYS.between(LocalDate.now(), c.getExpiryDate());
                inventoryService.createExpiryWatch(c.getComponentId(), (int) daysLeft);
                log.info("Flagged component {} expiring in {} days", c.getComponentId(), daysLeft);
            }
        }

        List<BloodComponent> expired = bloodComponentRepository.findByExpiryDateBefore(LocalDate.now());
        for (BloodComponent c : expired) {
            if (c.getStatus() == ComponentStatus.AVAILABLE) {
                c.setStatus(ComponentStatus.EXPIRED);
                bloodComponentRepository.save(c);
                log.info("Marked component {} as EXPIRED", c.getComponentId());
            }
        }

        log.info("Expiry scan complete. Flagged: {}, Expired: {}", expiring.size(), expired.size());
    }

    @Scheduled(cron = "0 0 7 * * *")
    public void scanLowStock() {
        log.info("Running low stock scan...");
    }
}