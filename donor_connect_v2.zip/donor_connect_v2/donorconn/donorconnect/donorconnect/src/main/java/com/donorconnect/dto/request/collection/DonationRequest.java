package com.donorconnect.dto.request.collection;
import com.donorconnect.enums.Enums.*;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;

@Data
public class DonationRequest {
    @NotNull private Long donorId;
    private LocalDate collectionDate;
    @NotBlank private String bagId;
    private Integer volumeMl;
    private String collectedBy;
    private CollectionStatus collectionStatus;
}
