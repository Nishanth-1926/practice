package com.donorconnect.dto.request.inventory;
import com.donorconnect.enums.Enums.*;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;

@Data
public class StockTransactionRequest {
    @NotNull private Long componentId;
    private Long locationId;
    private TransactionType txnType;
    private Integer quantity;
    private LocalDate txnDate;
    private Long referenceId;
    private String notes;
}
