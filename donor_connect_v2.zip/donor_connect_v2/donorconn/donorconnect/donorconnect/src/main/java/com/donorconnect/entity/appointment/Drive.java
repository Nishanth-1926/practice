package com.donorconnect.entity.appointment;

import com.donorconnect.enums.Enums.*;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "drives")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Drive {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long driveId;

    @Column(nullable = false)
    private String name;

    private String location;

    private LocalDate scheduledDate;

    private Integer capacity;

    private String organizer;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private DriveStatus status = DriveStatus.PLANNED;
}
