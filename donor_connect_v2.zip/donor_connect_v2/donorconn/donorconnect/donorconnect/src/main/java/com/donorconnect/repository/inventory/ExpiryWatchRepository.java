package com.donorconnect.repository.inventory;

import com.donorconnect.entity.inventory.ExpiryWatch;
import com.donorconnect.enums.Enums.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ExpiryWatchRepository extends JpaRepository<ExpiryWatch, Long> {
    List<ExpiryWatch> findByStatus(ExpiryWatchStatus status);
    boolean existsByComponentIdAndStatus(Long componentId, ExpiryWatchStatus status);
}
