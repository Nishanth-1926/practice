package com.donorconnect.entity.transfusion;

import com.donorconnect.enums.Enums.*;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "crossmatch_requests")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CrossmatchRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long requestId;

    @Column(nullable = false)
    private Long patientId;

    private String orderBy;

    private String bloodGroup;

    private String rhFactor;

    private Integer requiredUnits;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private CrossmatchPriority priority = CrossmatchPriority.ROUTINE;

    private LocalDate requestDate;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private CrossmatchStatus status = CrossmatchStatus.PENDING;
}
