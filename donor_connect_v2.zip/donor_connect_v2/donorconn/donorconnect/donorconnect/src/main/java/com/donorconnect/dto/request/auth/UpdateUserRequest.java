package com.donorconnect.dto.request.auth;
import com.donorconnect.enums.Enums.*;
import lombok.Data;

@Data
public class UpdateUserRequest {
    private String name;
    private String phone;
    private UserRole role;
    private UserStatus status;
}
