package com.donorconnect.service.appointment;

import com.donorconnect.dto.request.appointment.DriveRequest;
import com.donorconnect.entity.appointment.DonationAppointment;
import com.donorconnect.entity.appointment.Drive;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.exception.ResourceNotFoundException;
import com.donorconnect.repository.appointment.DonationAppointmentRepository;
import com.donorconnect.repository.appointment.DriveRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DriveService {

    private final DriveRepository driveRepository;
    private final DonationAppointmentRepository appointmentRepository;

    public Drive create(DriveRequest req) {
        Drive d = Drive.builder()
                .name(req.getName())
                .location(req.getLocation())
                .scheduledDate(req.getScheduledDate())
                .capacity(req.getCapacity())
                .organizer(req.getOrganizer())
                .status(DriveStatus.PLANNED)
                .build();
        return driveRepository.save(d);
    }

    public List<Drive> getAll() {
        return driveRepository.findAll();
    }

    public Drive getById(Long id) {
        return driveRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Drive", id));
    }

    public List<Drive> getUpcoming() {
        return driveRepository.findByScheduledDateAfter(LocalDate.now());
    }

    public Drive update(Long id, DriveRequest req) {
        Drive d = getById(id);
        if (req.getName() != null) d.setName(req.getName());
        if (req.getLocation() != null) d.setLocation(req.getLocation());
        if (req.getScheduledDate() != null) d.setScheduledDate(req.getScheduledDate());
        if (req.getCapacity() != null) d.setCapacity(req.getCapacity());
        if (req.getOrganizer() != null) d.setOrganizer(req.getOrganizer());
        return driveRepository.save(d);
    }

    public Drive updateStatus(Long id, DriveStatus status) {
        Drive d = getById(id);
        d.setStatus(status);
        return driveRepository.save(d);
    }

    public List<DonationAppointment> getAppointmentsByDrive(Long driveId) {
        return appointmentRepository.findByDriveId(driveId);
    }
}
