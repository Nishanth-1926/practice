package com.donorconnect.repository.transfusion;

import com.donorconnect.entity.transfusion.CrossmatchRequest;
import com.donorconnect.enums.Enums.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CrossmatchRequestRepository extends JpaRepository<CrossmatchRequest, Long> {
    List<CrossmatchRequest> findByPatientId(Long patientId);
    List<CrossmatchRequest> findByStatus(CrossmatchStatus status);
}
