package com.donorconnect.controller.billing;

import com.donorconnect.dto.request.billing.BillingRequest;
import com.donorconnect.dto.response.ApiResponse;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.service.billing.BillingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/v1/billing")
@RequiredArgsConstructor
@Tag(name = "Billing", description = "Billing reference for blood component issues")
public class BillingController {

    private final BillingService billingService;

    @PostMapping
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Create billing record")
    public ResponseEntity<ApiResponse<?>> create(@RequestBody BillingRequest request) {
        return ResponseEntity.ok(ApiResponse.success("Billing record created", billingService.create(request)));
    }

    @GetMapping
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "All billing records (paginated)")
    public ResponseEntity<ApiResponse<?>> getAll(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(ApiResponse.success(billingService.getAll(PageRequest.of(page, size))));
    }

    @GetMapping("/{billingId}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Get billing record by ID")
    public ResponseEntity<ApiResponse<?>> getById(@PathVariable Long billingId) {
        return ResponseEntity.ok(ApiResponse.success(billingService.getById(billingId)));
    }

    @GetMapping("/issue/{issueId}")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Billing record for an issue")
    public ResponseEntity<ApiResponse<?>> getByIssue(@PathVariable Long issueId) {
        return ResponseEntity.ok(ApiResponse.success(billingService.getByIssue(issueId)));
    }

    @GetMapping("/export")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Export billing data by date range")
    public ResponseEntity<ApiResponse<?>> export(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {
        return ResponseEntity.ok(ApiResponse.success(billingService.exportByDateRange(from, to)));
    }

    @PatchMapping("/{billingId}/status")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @Operation(summary = "Update billing status")
    public ResponseEntity<ApiResponse<?>> updateStatus(@PathVariable Long billingId,
                                                        @RequestParam BillingStatus status) {
        return ResponseEntity.ok(ApiResponse.success("Status updated", billingService.updateStatus(billingId, status)));
    }
}
