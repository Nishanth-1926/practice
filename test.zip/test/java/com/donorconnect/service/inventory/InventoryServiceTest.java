package com.donorconnect.service.inventory;

import com.donorconnect.dto.request.inventory.StockTransactionRequest;
import com.donorconnect.entity.inventory.ExpiryWatch;
import com.donorconnect.entity.inventory.InventoryBalance;
import com.donorconnect.entity.inventory.StockTransaction;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.exception.InsufficientStockException;
import com.donorconnect.exception.ResourceNotFoundException;
import com.donorconnect.repository.inventory.ExpiryWatchRepository;
import com.donorconnect.repository.inventory.InventoryBalanceRepository;
import com.donorconnect.repository.inventory.StockTransactionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("InventoryService Tests")
class InventoryServiceTest {

    @Mock
    private InventoryBalanceRepository inventoryBalanceRepository;

    @Mock
    private StockTransactionRepository stockTransactionRepository;

    @Mock
    private ExpiryWatchRepository expiryWatchRepository;

    @InjectMocks
    private InventoryService inventoryService;

    private InventoryBalance sampleBalance;
    private StockTransaction sampleTransaction;
    private ExpiryWatch sampleExpiryWatch;

    @BeforeEach
    void setUp() {
        sampleBalance = InventoryBalance.builder()
                .componentId(10L)
                .locationId(1L)
                .quantity(20)
                .status(ComponentStatus.AVAILABLE)
                .build();

        sampleTransaction = StockTransaction.builder()
                .componentId(10L)
                .locationId(1L)
                .txnType(TransactionType.RECEIPT)
                .quantity(5)
                .txnDate(LocalDate.now())
                .notes("Test transaction")
                .build();

        sampleExpiryWatch = ExpiryWatch.builder()
                .componentId(10L)
                .daysToExpire(3)
                .flagDate(LocalDate.now())
                .status(ExpiryWatchStatus.OPEN)
                .build();
    }

    // -------------------------  GET ALL  -------------------------

    @Test
    @DisplayName("getAll - returns all inventory balances")
    void getAll_returnsAllBalances() {
        when(inventoryBalanceRepository.findAll()).thenReturn(List.of(sampleBalance));

        List<InventoryBalance> result = inventoryService.getAll();

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getComponentId()).isEqualTo(10L);
    }

    @Test
    @DisplayName("getAll - returns empty list when no balances")
    void getAll_returnsEmptyList() {
        when(inventoryBalanceRepository.findAll()).thenReturn(List.of());

        List<InventoryBalance> result = inventoryService.getAll();

        assertThat(result).isEmpty();
    }

    // -------------------------  GET BY BLOOD GROUP  -------------------------

    @Test
    @DisplayName("getByBloodGroup - returns matching balances")
    void getByBloodGroup_returnsMatchingBalances() {
        when(inventoryBalanceRepository.findByBloodGroup("O+")).thenReturn(List.of(sampleBalance));

        List<InventoryBalance> result = inventoryService.getByBloodGroup("O+");

        assertThat(result).hasSize(1);
    }

    // -------------------------  GET LOW STOCK  -------------------------

    @Test
    @DisplayName("getLowStock - returns balances below threshold")
    void getLowStock_returnsBelowThreshold() {
        InventoryBalance lowBalance = InventoryBalance.builder()
                .componentId(20L).quantity(2).status(ComponentStatus.AVAILABLE).build();
        when(inventoryBalanceRepository.findByQuantityLessThan(5)).thenReturn(List.of(lowBalance));

        List<InventoryBalance> result = inventoryService.getLowStock();

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getQuantity()).isLessThan(5);
    }

    // -------------------------  CREATE TRANSACTION - RECEIPT  -------------------------

    @Test
    @DisplayName("createTransaction - RECEIPT creates new balance when none exists")
    void createTransaction_receipt_createsNewBalance() {
        StockTransactionRequest req = new StockTransactionRequest();
        req.setComponentId(99L);
        req.setLocationId(1L);
        req.setTxnType(TransactionType.RECEIPT);
        req.setQuantity(10);
        req.setTxnDate(LocalDate.now());

        when(stockTransactionRepository.save(any(StockTransaction.class))).thenReturn(sampleTransaction);
        when(inventoryBalanceRepository.findAll()).thenReturn(List.of()); // no existing balance

        StockTransaction result = inventoryService.createTransaction(req);

        assertThat(result).isNotNull();
        verify(inventoryBalanceRepository).save(any(InventoryBalance.class));
    }

    @Test
    @DisplayName("createTransaction - RECEIPT increments existing balance")
    void createTransaction_receipt_incrementsExistingBalance() {
        StockTransactionRequest req = new StockTransactionRequest();
        req.setComponentId(10L);
        req.setLocationId(1L);
        req.setTxnType(TransactionType.RECEIPT);
        req.setQuantity(5);

        when(stockTransactionRepository.save(any(StockTransaction.class))).thenReturn(sampleTransaction);
        when(inventoryBalanceRepository.findAll()).thenReturn(List.of(sampleBalance));
        when(inventoryBalanceRepository.save(any(InventoryBalance.class))).thenAnswer(inv -> inv.getArgument(0));

        inventoryService.createTransaction(req);

        assertThat(sampleBalance.getQuantity()).isEqualTo(25); // 20 + 5
    }

    // -------------------------  CREATE TRANSACTION - ISSUE  -------------------------

    @Test
    @DisplayName("createTransaction - ISSUE decrements existing balance")
    void createTransaction_issue_decrementsBalance() {
        StockTransactionRequest req = new StockTransactionRequest();
        req.setComponentId(10L);
        req.setLocationId(1L);
        req.setTxnType(TransactionType.ISSUE);
        req.setQuantity(5);

        when(stockTransactionRepository.save(any(StockTransaction.class))).thenReturn(sampleTransaction);
        when(inventoryBalanceRepository.findAll()).thenReturn(List.of(sampleBalance));
        when(inventoryBalanceRepository.save(any(InventoryBalance.class))).thenAnswer(inv -> inv.getArgument(0));

        inventoryService.createTransaction(req);

        assertThat(sampleBalance.getQuantity()).isEqualTo(15); // 20 - 5
    }

    @Test
    @DisplayName("createTransaction - ISSUE throws InsufficientStockException when quantity exceeds balance")
    void createTransaction_issue_throwsWhenInsufficientStock() {
        StockTransactionRequest req = new StockTransactionRequest();
        req.setComponentId(10L);
        req.setTxnType(TransactionType.ISSUE);
        req.setQuantity(100); // more than available 20

        when(stockTransactionRepository.save(any(StockTransaction.class))).thenReturn(sampleTransaction);
        when(inventoryBalanceRepository.findAll()).thenReturn(List.of(sampleBalance));

        assertThatThrownBy(() -> inventoryService.createTransaction(req))
                .isInstanceOf(InsufficientStockException.class);
        verify(inventoryBalanceRepository, never()).save(any(InventoryBalance.class));
    }

    // -------------------------  CREATE TRANSACTION - TRANSFER_OUT  -------------------------

    @Test
    @DisplayName("createTransaction - TRANSFER_OUT throws when stock insufficient")
    void createTransaction_transferOut_throwsWhenInsufficientStock() {
        StockTransactionRequest req = new StockTransactionRequest();
        req.setComponentId(10L);
        req.setTxnType(TransactionType.TRANSFER_OUT);
        req.setQuantity(50);

        when(stockTransactionRepository.save(any(StockTransaction.class))).thenReturn(sampleTransaction);
        when(inventoryBalanceRepository.findAll()).thenReturn(List.of(sampleBalance));

        assertThatThrownBy(() -> inventoryService.createTransaction(req))
                .isInstanceOf(InsufficientStockException.class);
    }

    @Test
    @DisplayName("createTransaction - uses today's date when txnDate is null")
    void createTransaction_usesTodayWhenDateIsNull() {
        StockTransactionRequest req = new StockTransactionRequest();
        req.setComponentId(10L);
        req.setTxnType(TransactionType.RECEIPT);
        req.setQuantity(3);
        req.setTxnDate(null); // intentionally null

        when(stockTransactionRepository.save(any(StockTransaction.class))).thenAnswer(inv -> inv.getArgument(0));
        when(inventoryBalanceRepository.findAll()).thenReturn(List.of());

        StockTransaction result = inventoryService.createTransaction(req);

        // Verify the saved transaction has today's date (captured via arg captor logic)
        verify(stockTransactionRepository).save(argThat(t -> t.getTxnDate().equals(LocalDate.now())));
    }

    // -------------------------  GET ALL TRANSACTIONS  -------------------------

    @Test
    @DisplayName("getAllTransactions - returns paginated transactions")
    void getAllTransactions_returnsPaginatedTransactions() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<StockTransaction> page = new PageImpl<>(List.of(sampleTransaction));
        when(stockTransactionRepository.findAll(pageable)).thenReturn(page);

        Page<StockTransaction> result = inventoryService.getAllTransactions(pageable);

        assertThat(result.getContent()).hasSize(1);
    }

    // -------------------------  GET TRANSACTION BY ID  -------------------------

    @Test
    @DisplayName("getTransactionById - existing id returns transaction")
    void getTransactionById_existingId_returnsTransaction() {
        when(stockTransactionRepository.findById(1L)).thenReturn(Optional.of(sampleTransaction));

        StockTransaction result = inventoryService.getTransactionById(1L);

        assertThat(result).isNotNull();
    }

    @Test
    @DisplayName("getTransactionById - missing id throws ResourceNotFoundException")
    void getTransactionById_missingId_throwsException() {
        when(stockTransactionRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> inventoryService.getTransactionById(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    // -------------------------  GET TRANSACTIONS BY COMPONENT  -------------------------

    @Test
    @DisplayName("getTransactionsByComponent - returns transactions for component")
    void getTransactionsByComponent_returnsTransactions() {
        when(stockTransactionRepository.findByComponentId(10L)).thenReturn(List.of(sampleTransaction));

        List<StockTransaction> result = inventoryService.getTransactionsByComponent(10L);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getComponentId()).isEqualTo(10L);
    }

    // -------------------------  GET TRANSACTIONS BY TYPE  -------------------------

    @Test
    @DisplayName("getTransactionsByType - returns transactions matching type")
    void getTransactionsByType_returnsMatchingTransactions() {
        when(stockTransactionRepository.findByTxnType(TransactionType.RECEIPT))
                .thenReturn(List.of(sampleTransaction));

        List<StockTransaction> result = inventoryService.getTransactionsByType(TransactionType.RECEIPT);

        assertThat(result).hasSize(1);
    }

    // -------------------------  EXPIRY WATCH  -------------------------

    @Test
    @DisplayName("getAllExpiryWatch - returns all expiry watches")
    void getAllExpiryWatch_returnsAll() {
        when(expiryWatchRepository.findAll()).thenReturn(List.of(sampleExpiryWatch));

        List<ExpiryWatch> result = inventoryService.getAllExpiryWatch();

        assertThat(result).hasSize(1);
    }

    @Test
    @DisplayName("getOpenExpiryWatch - returns only OPEN expiry watches")
    void getOpenExpiryWatch_returnsOnlyOpen() {
        when(expiryWatchRepository.findByStatus(ExpiryWatchStatus.OPEN))
                .thenReturn(List.of(sampleExpiryWatch));

        List<ExpiryWatch> result = inventoryService.getOpenExpiryWatch();

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getStatus()).isEqualTo(ExpiryWatchStatus.OPEN);
    }

    @Test
    @DisplayName("actionExpiryWatch - changes status to ACTIONED")
    void actionExpiryWatch_changesStatusToActioned() {
        when(expiryWatchRepository.findById(1L)).thenReturn(Optional.of(sampleExpiryWatch));
        when(expiryWatchRepository.save(any(ExpiryWatch.class))).thenAnswer(inv -> inv.getArgument(0));

        ExpiryWatch result = inventoryService.actionExpiryWatch(1L);

        assertThat(result.getStatus()).isEqualTo(ExpiryWatchStatus.ACTIONED);
        verify(expiryWatchRepository).save(sampleExpiryWatch);
    }

    @Test
    @DisplayName("actionExpiryWatch - not found throws ResourceNotFoundException")
    void actionExpiryWatch_notFound_throwsException() {
        when(expiryWatchRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> inventoryService.actionExpiryWatch(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("createExpiryWatch - creates new watch when none exists for component")
    void createExpiryWatch_createsNewWhenNoneExists() {
        when(expiryWatchRepository.existsByComponentIdAndStatus(10L, ExpiryWatchStatus.OPEN))
                .thenReturn(false);

        inventoryService.createExpiryWatch(10L, 3);

        verify(expiryWatchRepository).save(any(ExpiryWatch.class));
    }

    @Test
    @DisplayName("createExpiryWatch - does not create duplicate when OPEN watch already exists")
    void createExpiryWatch_doesNotCreateDuplicate() {
        when(expiryWatchRepository.existsByComponentIdAndStatus(10L, ExpiryWatchStatus.OPEN))
                .thenReturn(true);

        inventoryService.createExpiryWatch(10L, 3);

        verify(expiryWatchRepository, never()).save(any(ExpiryWatch.class));
    }
}
