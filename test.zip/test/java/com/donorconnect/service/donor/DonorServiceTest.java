package com.donorconnect.service.donor;

import com.donorconnect.dto.request.donor.DonorRequest;
import com.donorconnect.entity.collection.Donation;
import com.donorconnect.entity.donor.Donor;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.exception.ResourceNotFoundException;
import com.donorconnect.repository.collection.DonationRepository;
import com.donorconnect.repository.donor.DonorRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.*;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("DonorService Tests")
class DonorServiceTest {

    @Mock
    private DonorRepository donorRepository;

    @Mock
    private DonationRepository donationRepository;

    @InjectMocks
    private DonorService donorService;

    private Donor sampleDonor;
    private DonorRequest sampleRequest;

    @BeforeEach
    void setUp() {
        sampleDonor = Donor.builder()
                .donorId(1L)
                .name("John Doe")
                .dob("1990-01-15")
                .gender("Male")
                .bloodGroup("O+")
                .rhFactor("Positive")
                .contactInfo("john@example.com")
                .addressJson("{\"city\":\"Chennai\"}")
                .donorType(DonorType.VOLUNTARY)
                .status(DonorStatus.ACTIVE)
                .build();

        sampleRequest = new DonorRequest();
        sampleRequest.setName("John Doe");
        sampleRequest.setDob("1990-01-15");
        sampleRequest.setGender("Male");
        sampleRequest.setBloodGroup("O+");
        sampleRequest.setRhFactor("Positive");
        sampleRequest.setContactInfo("john@example.com");
        sampleRequest.setAddressJson("{\"city\":\"Chennai\"}");
        sampleRequest.setDonorType(DonorType.VOLUNTARY);
    }

    // -------------------------  CREATE  -------------------------

    @Test
    @DisplayName("create - saves and returns new donor")
    void create_savesAndReturnsNewDonor() {
        when(donorRepository.save(any(Donor.class))).thenReturn(sampleDonor);

        Donor result = donorService.create(sampleRequest);

        assertThat(result).isNotNull();
        assertThat(result.getName()).isEqualTo("John Doe");
        assertThat(result.getBloodGroup()).isEqualTo("O+");
        assertThat(result.getStatus()).isEqualTo(DonorStatus.ACTIVE);
        verify(donorRepository).save(any(Donor.class));
    }

    @Test
    @DisplayName("create - donor status defaults to ACTIVE")
    void create_donorStatusDefaultsToActive() {
        when(donorRepository.save(any(Donor.class))).thenAnswer(inv -> {
            Donor d = inv.getArgument(0);
            return d;
        });

        Donor result = donorService.create(sampleRequest);

        assertThat(result.getStatus()).isEqualTo(DonorStatus.ACTIVE);
    }

    // -------------------------  GET ALL  -------------------------

    @Test
    @DisplayName("getAll - returns paginated donors")
    void getAll_returnsPaginatedDonors() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<Donor> page = new PageImpl<>(List.of(sampleDonor));
        when(donorRepository.findAll(pageable)).thenReturn(page);

        Page<Donor> result = donorService.getAll(pageable);

        assertThat(result.getContent()).hasSize(1);
        assertThat(result.getContent().get(0).getName()).isEqualTo("John Doe");
    }

    @Test
    @DisplayName("getAll - returns empty page when no donors")
    void getAll_returnsEmptyPage() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<Donor> emptyPage = new PageImpl<>(List.of());
        when(donorRepository.findAll(pageable)).thenReturn(emptyPage);

        Page<Donor> result = donorService.getAll(pageable);

        assertThat(result.getContent()).isEmpty();
    }

    // -------------------------  GET BY ID  -------------------------

    @Test
    @DisplayName("getById - existing id returns donor")
    void getById_existingId_returnsDonor() {
        when(donorRepository.findById(1L)).thenReturn(Optional.of(sampleDonor));

        Donor result = donorService.getById(1L);

        assertThat(result).isNotNull();
        assertThat(result.getDonorId()).isEqualTo(1L);
        assertThat(result.getName()).isEqualTo("John Doe");
    }

    @Test
    @DisplayName("getById - missing id throws ResourceNotFoundException")
    void getById_missingId_throwsException() {
        when(donorRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> donorService.getById(99L))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("99");
    }

    // -------------------------  SEARCH  -------------------------

    @Test
    @DisplayName("search - by name returns matching donors")
    void search_byName_returnsMatchingDonors() {
        when(donorRepository.searchDonors("John", null)).thenReturn(List.of(sampleDonor));

        List<Donor> result = donorService.search("John", null);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getName()).isEqualTo("John Doe");
    }

    @Test
    @DisplayName("search - by blood group returns matching donors")
    void search_byBloodGroup_returnsMatchingDonors() {
        when(donorRepository.searchDonors(null, "O+")).thenReturn(List.of(sampleDonor));

        List<Donor> result = donorService.search(null, "O+");

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getBloodGroup()).isEqualTo("O+");
    }

    @Test
    @DisplayName("search - no match returns empty list")
    void search_noMatch_returnsEmptyList() {
        when(donorRepository.searchDonors("Unknown", "Z-")).thenReturn(List.of());

        List<Donor> result = donorService.search("Unknown", "Z-");

        assertThat(result).isEmpty();
    }

    // -------------------------  UPDATE  -------------------------

    @Test
    @DisplayName("update - updates name field")
    void update_updatesName() {
        DonorRequest req = new DonorRequest();
        req.setName("Jane Doe");

        when(donorRepository.findById(1L)).thenReturn(Optional.of(sampleDonor));
        when(donorRepository.save(any(Donor.class))).thenAnswer(inv -> inv.getArgument(0));

        Donor result = donorService.update(1L, req);

        assertThat(result.getName()).isEqualTo("Jane Doe");
        verify(donorRepository).save(sampleDonor);
    }

    @Test
    @DisplayName("update - updates blood group field")
    void update_updatesBloodGroup() {
        DonorRequest req = new DonorRequest();
        req.setBloodGroup("A+");

        when(donorRepository.findById(1L)).thenReturn(Optional.of(sampleDonor));
        when(donorRepository.save(any(Donor.class))).thenAnswer(inv -> inv.getArgument(0));

        Donor result = donorService.update(1L, req);

        assertThat(result.getBloodGroup()).isEqualTo("A+");
    }

    @Test
    @DisplayName("update - null fields are not overwritten")
    void update_nullFieldsAreNotOverwritten() {
        DonorRequest req = new DonorRequest();
        // all fields null except name
        req.setName("Updated Only");

        when(donorRepository.findById(1L)).thenReturn(Optional.of(sampleDonor));
        when(donorRepository.save(any(Donor.class))).thenAnswer(inv -> inv.getArgument(0));

        Donor result = donorService.update(1L, req);

        assertThat(result.getName()).isEqualTo("Updated Only");
        assertThat(result.getBloodGroup()).isEqualTo("O+"); // unchanged
        assertThat(result.getGender()).isEqualTo("Male");   // unchanged
    }

    @Test
    @DisplayName("update - donor not found throws ResourceNotFoundException")
    void update_donorNotFound_throwsException() {
        when(donorRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> donorService.update(99L, sampleRequest))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    // -------------------------  UPDATE STATUS  -------------------------

    @Test
    @DisplayName("updateStatus - sets status to DEFERRED")
    void updateStatus_setsStatusDeferred() {
        when(donorRepository.findById(1L)).thenReturn(Optional.of(sampleDonor));
        when(donorRepository.save(any(Donor.class))).thenAnswer(inv -> inv.getArgument(0));

        Donor result = donorService.updateStatus(1L, DonorStatus.DEFERRED);

        assertThat(result.getStatus()).isEqualTo(DonorStatus.DEFERRED);
    }

    @Test
    @DisplayName("updateStatus - sets status to BLACKLISTED")
    void updateStatus_setsStatusBlacklisted() {
        when(donorRepository.findById(1L)).thenReturn(Optional.of(sampleDonor));
        when(donorRepository.save(any(Donor.class))).thenAnswer(inv -> inv.getArgument(0));

        Donor result = donorService.updateStatus(1L, DonorStatus.BLACKLISTED);

        assertThat(result.getStatus()).isEqualTo(DonorStatus.BLACKLISTED);
    }

    // -------------------------  DONATION HISTORY  -------------------------

    @Test
    @DisplayName("getDonationHistory - returns donations for donor")
    void getDonationHistory_returnsDonations() {
        Donation donation = Donation.builder().donorId(1L).build();
        when(donationRepository.findByDonorId(1L)).thenReturn(List.of(donation));

        List<Donation> result = donorService.getDonationHistory(1L);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getDonorId()).isEqualTo(1L);
    }

    @Test
    @DisplayName("getDonationHistory - returns empty list when no donations")
    void getDonationHistory_returnsEmptyList() {
        when(donationRepository.findByDonorId(1L)).thenReturn(List.of());

        List<Donation> result = donorService.getDonationHistory(1L);

        assertThat(result).isEmpty();
    }

    // -------------------------  GET BY BLOOD GROUP  -------------------------

    @Test
    @DisplayName("getByBloodGroup - returns donors with matching blood group")
    void getByBloodGroup_returnsMatchingDonors() {
        when(donorRepository.findByBloodGroup("O+")).thenReturn(List.of(sampleDonor));

        List<Donor> result = donorService.getByBloodGroup("O+");

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getBloodGroup()).isEqualTo("O+");
    }

    // -------------------------  GET BY TYPE  -------------------------

    @Test
    @DisplayName("getByType - returns voluntary donors")
    void getByType_returnsVoluntaryDonors() {
        when(donorRepository.findByDonorType(DonorType.VOLUNTARY)).thenReturn(List.of(sampleDonor));

        List<Donor> result = donorService.getByType(DonorType.VOLUNTARY);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getDonorType()).isEqualTo(DonorType.VOLUNTARY);
    }
}
