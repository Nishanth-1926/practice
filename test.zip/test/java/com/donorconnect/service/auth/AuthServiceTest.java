package com.donorconnect.service.auth;

import com.donorconnect.dto.request.auth.*;
import com.donorconnect.entity.auth.AuditLog;
import com.donorconnect.entity.auth.User;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.exception.InvalidPasswordException;
import com.donorconnect.exception.ResourceNotFoundException;
import com.donorconnect.exception.UserAlreadyExistsException;
import com.donorconnect.repository.auth.AuditLogRepository;
import com.donorconnect.repository.auth.UserRepository;
import com.donorconnect.security.JwtTokenProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.*;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.*;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("AuthService Tests")
class AuthServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private AuditLogRepository auditLogRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private AuthenticationManager authenticationManager;

    @Mock
    private JwtTokenProvider tokenProvider;

    @InjectMocks
    private AuthService authService;

    private User sampleUser;

    @BeforeEach
    void setUp() {
        sampleUser = User.builder()
                .userId(1L)
                .name("Test User")
                .email("test@example.com")
                .phone("9876543210")
                .password("encodedPassword")
                .role(UserRole.ROLE_DONOR)
                .status(UserStatus.ACTIVE)
                .build();
    }

    // -------------------------  LOGIN  -------------------------

    @Test
    @DisplayName("login - success returns token map")
    void login_success_returnsTokenMap() {
        LoginRequest req = new LoginRequest();
        req.setEmail("test@example.com");
        req.setPassword("password123");

        Authentication auth = mock(Authentication.class);
        when(authenticationManager.authenticate(any())).thenReturn(auth);
        when(tokenProvider.generateToken(auth)).thenReturn("jwt-token");
        when(userRepository.findByEmail("test@example.com")).thenReturn(Optional.of(sampleUser));
        when(auditLogRepository.save(any(AuditLog.class))).thenReturn(mock(AuditLog.class));

        Map<String, String> result = authService.login(req);

        assertThat(result).containsKey("token");
        assertThat(result.get("token")).isEqualTo("jwt-token");
        assertThat(result.get("email")).isEqualTo("test@example.com");
        assertThat(result.get("role")).isEqualTo(UserRole.ROLE_DONOR.name());
        assertThat(result.get("name")).isEqualTo("Test User");
        verify(auditLogRepository).save(any(AuditLog.class));
    }

    @Test
    @DisplayName("login - bad credentials throws exception")
    void login_badCredentials_throwsException() {
        LoginRequest req = new LoginRequest();
        req.setEmail("wrong@example.com");
        req.setPassword("wrongpass");

        when(authenticationManager.authenticate(any()))
                .thenThrow(new BadCredentialsException("Bad credentials"));

        assertThatThrownBy(() -> authService.login(req))
                .isInstanceOf(BadCredentialsException.class);
    }

    // -------------------------  REGISTER  -------------------------

    @Test
    @DisplayName("register - new user is saved successfully")
    void register_newUser_savedSuccessfully() {
        RegisterRequest req = new RegisterRequest();
        req.setName("New User");
        req.setEmail("newuser@example.com");
        req.setPassword("pass123");
        req.setRole(UserRole.ROLE_DONOR);
        req.setPhone("1234567890");

        when(userRepository.existsByEmail("newuser@example.com")).thenReturn(false);
        when(passwordEncoder.encode("pass123")).thenReturn("encodedPass");
        when(userRepository.save(any(User.class))).thenReturn(sampleUser);

        User result = authService.register(req);

        assertThat(result).isNotNull();
        verify(userRepository).save(any(User.class));
    }

    @Test
    @DisplayName("register - duplicate email throws UserAlreadyExistsException")
    void register_duplicateEmail_throwsException() {
        RegisterRequest req = new RegisterRequest();
        req.setEmail("test@example.com");
        req.setName("Duplicate");
        req.setPassword("pass123");
        req.setRole(UserRole.ROLE_DONOR);

        when(userRepository.existsByEmail("test@example.com")).thenReturn(true);

        assertThatThrownBy(() -> authService.register(req))
                .isInstanceOf(UserAlreadyExistsException.class);
        verify(userRepository, never()).save(any());
    }

    // -------------------------  CHANGE PASSWORD  -------------------------

    @Test
    @DisplayName("changePassword - correct old password updates successfully")
    void changePassword_correctOldPassword_updatesSuccessfully() {
        ChangePasswordRequest req = new ChangePasswordRequest();
        req.setOldPassword("oldPass");
        req.setNewPassword("newPass123");

        when(userRepository.findByEmail("test@example.com")).thenReturn(Optional.of(sampleUser));
        when(passwordEncoder.matches("oldPass", sampleUser.getPassword())).thenReturn(true);
        when(passwordEncoder.encode("newPass123")).thenReturn("encodedNew");
        when(userRepository.save(any(User.class))).thenReturn(sampleUser);

        authService.changePassword("test@example.com", req);

        verify(userRepository).save(any(User.class));
    }

    @Test
    @DisplayName("changePassword - wrong old password throws InvalidPasswordException")
    void changePassword_wrongOldPassword_throwsException() {
        ChangePasswordRequest req = new ChangePasswordRequest();
        req.setOldPassword("wrongOld");
        req.setNewPassword("newPass123");

        when(userRepository.findByEmail("test@example.com")).thenReturn(Optional.of(sampleUser));
        when(passwordEncoder.matches("wrongOld", sampleUser.getPassword())).thenReturn(false);

        assertThatThrownBy(() -> authService.changePassword("test@example.com", req))
                .isInstanceOf(InvalidPasswordException.class);
        verify(userRepository, never()).save(any());
    }

    @Test
    @DisplayName("changePassword - user not found throws ResourceNotFoundException")
    void changePassword_userNotFound_throwsException() {
        ChangePasswordRequest req = new ChangePasswordRequest();
        req.setOldPassword("old");
        req.setNewPassword("new");

        when(userRepository.findByEmail("notfound@example.com"))
                .thenReturn(Optional.empty());

        assertThatThrownBy(() -> authService.changePassword("notfound@example.com", req))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    // -------------------------  FORGOT PASSWORD  -------------------------

    @Test
    @DisplayName("forgotPassword - valid email returns reset token message")
    void forgotPassword_validEmail_returnsToken() {
        when(userRepository.findByEmail("test@example.com")).thenReturn(Optional.of(sampleUser));

        String result = authService.forgotPassword("test@example.com");

        assertThat(result).contains("Token:");
    }

    @Test
    @DisplayName("forgotPassword - unknown email throws ResourceNotFoundException")
    void forgotPassword_unknownEmail_throwsException() {
        when(userRepository.findByEmail("ghost@example.com")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> authService.forgotPassword("ghost@example.com"))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    // -------------------------  RESET PASSWORD  -------------------------

    @Test
    @DisplayName("resetPassword - success returns confirmation message")
    void resetPassword_success_returnsConfirmation() {
        ResetPasswordRequest req = new ResetPasswordRequest();
        req.setEmail("test@example.com");
        req.setNewPassword("resetPass123");

        when(userRepository.findByEmail("test@example.com")).thenReturn(Optional.of(sampleUser));
        when(passwordEncoder.encode("resetPass123")).thenReturn("encodedReset");
        when(userRepository.save(any(User.class))).thenReturn(sampleUser);

        String result = authService.resetPassword(req);

        assertThat(result).isEqualTo("Password reset successful");
        verify(userRepository).save(any(User.class));
    }

    // -------------------------  GET USERS  -------------------------

    @Test
    @DisplayName("getAllUsers - returns paginated users")
    void getAllUsers_returnsPaginatedUsers() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<User> page = new PageImpl<>(List.of(sampleUser));
        when(userRepository.findAll(pageable)).thenReturn(page);

        Page<User> result = authService.getAllUsers(pageable);

        assertThat(result.getContent()).hasSize(1);
        assertThat(result.getContent().get(0).getEmail()).isEqualTo("test@example.com");
    }

    @Test
    @DisplayName("getUserById - existing id returns user")
    void getUserById_existingId_returnsUser() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(sampleUser));

        User result = authService.getUserById(1L);

        assertThat(result).isNotNull();
        assertThat(result.getUserId()).isEqualTo(1L);
    }

    @Test
    @DisplayName("getUserById - missing id throws ResourceNotFoundException")
    void getUserById_missingId_throwsException() {
        when(userRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> authService.getUserById(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    @DisplayName("getUsersByRole - returns matching users")
    void getUsersByRole_returnsMatchingUsers() {
        when(userRepository.findByRole(UserRole.ROLE_DONOR)).thenReturn(List.of(sampleUser));

        List<User> result = authService.getUsersByRole(UserRole.ROLE_DONOR);

        assertThat(result).hasSize(1);
    }

    @Test
    @DisplayName("getUsersByStatus - returns active users")
    void getUsersByStatus_returnsActiveUsers() {
        when(userRepository.findByStatus(UserStatus.ACTIVE)).thenReturn(List.of(sampleUser));

        List<User> result = authService.getUsersByStatus(UserStatus.ACTIVE);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getStatus()).isEqualTo(UserStatus.ACTIVE);
    }

    // -------------------------  UPDATE USER  -------------------------

    @Test
    @DisplayName("updateUser - updates name and phone")
    void updateUser_updatesNameAndPhone() {
        UpdateUserRequest req = new UpdateUserRequest();
        req.setName("Updated Name");
        req.setPhone("0000000000");

        when(userRepository.findById(1L)).thenReturn(Optional.of(sampleUser));
        when(userRepository.save(any(User.class))).thenAnswer(inv -> inv.getArgument(0));

        User result = authService.updateUser(1L, req);

        assertThat(result.getName()).isEqualTo("Updated Name");
        assertThat(result.getPhone()).isEqualTo("0000000000");
    }

    // -------------------------  LOCK / UNLOCK / DEACTIVATE  -------------------------

    @Test
    @DisplayName("lockUser - sets status to LOCKED")
    void lockUser_setsStatusLocked() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(sampleUser));
        when(userRepository.save(any(User.class))).thenAnswer(inv -> inv.getArgument(0));

        authService.lockUser(1L);

        assertThat(sampleUser.getStatus()).isEqualTo(UserStatus.LOCKED);
        verify(userRepository).save(sampleUser);
    }

    @Test
    @DisplayName("unlockUser - sets status to ACTIVE")
    void unlockUser_setsStatusActive() {
        sampleUser.setStatus(UserStatus.LOCKED);
        when(userRepository.findById(1L)).thenReturn(Optional.of(sampleUser));
        when(userRepository.save(any(User.class))).thenAnswer(inv -> inv.getArgument(0));

        authService.unlockUser(1L);

        assertThat(sampleUser.getStatus()).isEqualTo(UserStatus.ACTIVE);
    }

    @Test
    @DisplayName("deactivateUser - sets status to INACTIVE")
    void deactivateUser_setsStatusInactive() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(sampleUser));
        when(userRepository.save(any(User.class))).thenAnswer(inv -> inv.getArgument(0));

        authService.deactivateUser(1L);

        assertThat(sampleUser.getStatus()).isEqualTo(UserStatus.INACTIVE);
    }

    // -------------------------  AUDIT LOGS  -------------------------

    @Test
    @DisplayName("getAllAuditLogs - returns paginated audit logs")
    void getAllAuditLogs_returnsPaginatedLogs() {
        Pageable pageable = PageRequest.of(0, 10);
        AuditLog log = AuditLog.builder().userId(1L).action("LOGIN").resource("AUTH").build();
        Page<AuditLog> page = new PageImpl<>(List.of(log));
        when(auditLogRepository.findAll(pageable)).thenReturn(page);

        Page<AuditLog> result = authService.getAllAuditLogs(pageable);

        assertThat(result.getContent()).hasSize(1);
    }

    @Test
    @DisplayName("getAuditLogsByUser - returns logs for user")
    void getAuditLogsByUser_returnsLogsForUser() {
        AuditLog log = AuditLog.builder().userId(1L).action("LOGIN").resource("AUTH").build();
        when(auditLogRepository.findByUserId(1L)).thenReturn(List.of(log));

        List<AuditLog> result = authService.getAuditLogsByUser(1L);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getAction()).isEqualTo("LOGIN");
    }

    @Test
    @DisplayName("getAuditLogsByAction - returns logs matching action")
    void getAuditLogsByAction_returnsMatchingLogs() {
        AuditLog log = AuditLog.builder().userId(1L).action("LOGIN").resource("AUTH").build();
        when(auditLogRepository.findByAction("LOGIN")).thenReturn(List.of(log));

        List<AuditLog> result = authService.getAuditLogsByAction("LOGIN");

        assertThat(result).hasSize(1);
    }
}
