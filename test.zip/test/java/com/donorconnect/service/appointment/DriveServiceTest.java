package com.donorconnect.service.appointment;

import com.donorconnect.dto.request.appointment.DriveRequest;
import com.donorconnect.entity.appointment.DonationAppointment;
import com.donorconnect.entity.appointment.Drive;
import com.donorconnect.enums.Enums.DriveStatus;
import com.donorconnect.exception.ResourceNotFoundException;
import com.donorconnect.repository.appointment.DonationAppointmentRepository;
import com.donorconnect.repository.appointment.DriveRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class DriveServiceTest {

    @Mock
    private DriveRepository driveRepository;

    @Mock
    private DonationAppointmentRepository appointmentRepository;

    @InjectMocks
    private DriveService driveService;

    @Test
    void create() {
        DriveRequest request = Mockito.mock(DriveRequest.class);
        Mockito.when(request.getName()).thenReturn("Camp");
        Mockito.when(request.getLocation()).thenReturn("Chennai");
        Mockito.when(request.getScheduledDate()).thenReturn(LocalDate.now());
        Mockito.when(request.getCapacity()).thenReturn(100);
        Mockito.when(request.getOrganizer()).thenReturn("Org");

        Drive saved = Drive.builder()
                .name("Camp")
                .location("Chennai")
                .scheduledDate(LocalDate.now())
                .capacity(100)
                .organizer("Org")
                .status(DriveStatus.PLANNED)
                .build();

        saved.setDriveId(1L);

        Mockito.when(driveRepository.save(Mockito.any()))
                .thenReturn(saved);

        Drive result = driveService.create(request);

        assertEquals(DriveStatus.PLANNED, result.getStatus());
        assertEquals(1L, result.getDriveId());
    }

    @Test
    void getAll() {
        Mockito.when(driveRepository.findAll())
                .thenReturn(List.of(new Drive()));

        List<Drive> result = driveService.getAll();

        assertEquals(1, result.size());
    }

    @Test
    void getById_found() {
        Drive drive = new Drive();
        Mockito.when(driveRepository.findById(1L))
                .thenReturn(Optional.of(drive));

        Drive result = driveService.getById(1L);

        assertNotNull(result);
    }

    @Test
    void getById_notFound() {
        Mockito.when(driveRepository.findById(1L))
                .thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class,
                () -> driveService.getById(1L));
    }

    @Test
    void getUpcoming() {
        Mockito.when(driveRepository.findByScheduledDateAfter(Mockito.any()))
                .thenReturn(List.of(new Drive()));

        List<Drive> result = driveService.getUpcoming();

        assertEquals(1, result.size());
    }

    @Test
    void update() {
        Drive drive = new Drive();
        Mockito.when(driveRepository.findById(1L))
                .thenReturn(Optional.of(drive));
        Mockito.when(driveRepository.save(Mockito.any()))
                .thenReturn(drive);

        DriveRequest request = Mockito.mock(DriveRequest.class);
        Mockito.when(request.getName()).thenReturn("Updated Camp");

        Drive result = driveService.update(1L, request);

        assertEquals("Updated Camp", result.getName());
    }

    @Test
    void updateStatus() {
        Drive drive = new Drive();
        Mockito.when(driveRepository.findById(1L))
                .thenReturn(Optional.of(drive));
        Mockito.when(driveRepository.save(Mockito.any()))
                .thenReturn(drive);

        Drive result = driveService.updateStatus(1L, DriveStatus.COMPLETED);

        assertEquals(DriveStatus.COMPLETED, result.getStatus());
    }

    @Test
    void getAppointmentsByDrive() {
        Mockito.when(appointmentRepository.findByDriveId(1L))
                .thenReturn(List.of(new DonationAppointment()));

        List<DonationAppointment> result =
                driveService.getAppointmentsByDrive(1L);

        assertEquals(1, result.size());
    }
}