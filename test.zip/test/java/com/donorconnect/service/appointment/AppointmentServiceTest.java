package com.donorconnect.service.appointment;

import com.donorconnect.entity.appointment.DonationAppointment;
import com.donorconnect.enums.Enums.AppointmentStatus;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class AppointmentServiceTest {

    @Test
    void defaultStatusIsBooked() {
        DonationAppointment appointment = new DonationAppointment();
        assertEquals(AppointmentStatus.BOOKED, appointment.getStatus());
    }

    @Test
    void builderSetsValuesCorrectly() {
        DonationAppointment appointment = DonationAppointment.builder()
                .appointmentId(1L)
                .donorId(10L)
                .centerId(5L)
                .driveId(3L)
                .status(AppointmentStatus.COMPLETED)
                .build();

        assertEquals(1L, appointment.getAppointmentId());
        assertEquals(10L, appointment.getDonorId());
        assertEquals(5L, appointment.getCenterId());
        assertEquals(3L, appointment.getDriveId());
        assertEquals(AppointmentStatus.COMPLETED, appointment.getStatus());
    }
}