package com.donorconnect.controller.adminconfig;

import com.donorconnect.controller.adminConfig.AdminController;
import com.donorconnect.dto.request.adminConfig.SystemConfigRequest;
import com.donorconnect.entity.adminConfig.SystemConfig;
import com.donorconnect.service.adminConfig.SystemConfigService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AdminController.class)
@AutoConfigureMockMvc(addFilters = false)
class AdminControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SystemConfigService systemConfigService;

    @Autowired
    private ObjectMapper objectMapper;

    private SystemConfigRequest request() {
        SystemConfigRequest r = new SystemConfigRequest();
        r.setKey("SITE_NAME");
        r.setValue("DonorConnect");
        r.setDescription("Site name");
        return r;
    }

    private SystemConfig config() {
        SystemConfig c = new SystemConfig();
        c.setId(1L);
        return c;
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void create() throws Exception {
        Mockito.when(systemConfigService.create(Mockito.any(), Mockito.anyString()))
                .thenReturn(config());

        mockMvc.perform(post("/api/v1/admin/config")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Config created"));
    }

    @Test
    void getAll() throws Exception {
        Mockito.when(systemConfigService.getAll())
                .thenReturn(List.of(config()));

        mockMvc.perform(get("/api/v1/admin/config"))
                .andExpect(status().isOk());
    }

    @Test
    void getById() throws Exception {
        Mockito.when(systemConfigService.getById(1L))
                .thenReturn(config());

        mockMvc.perform(get("/api/v1/admin/config/1"))
                .andExpect(status().isOk());
    }

    @Test
    void getByKey() throws Exception {
        Mockito.when(systemConfigService.getByKey("SITE_NAME"))
                .thenReturn(config());

        mockMvc.perform(get("/api/v1/admin/config/key/SITE_NAME"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void update() throws Exception {
        Mockito.when(systemConfigService.update(Mockito.eq(1L), Mockito.any(), Mockito.anyString()))
                .thenReturn(config());

        mockMvc.perform(put("/api/v1/admin/config/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Config updated"));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void delete() throws Exception {
        Mockito.doNothing().when(systemConfigService).delete(1L);

        mockMvc.perform(MockMvcRequestBuilders.delete("/api/v1/admin/config/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Config deleted"));
    }
}