package com.donorconnect.controller.inventory;

import com.donorconnect.dto.request.inventory.StockTransactionRequest;
import com.donorconnect.dto.response.ApiResponse;
import com.donorconnect.entity.inventory.InventoryBalance;
import com.donorconnect.service.inventory.InventoryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@DisplayName("InventoryController Test Suite")
public class InventoryControllerTest {

    @Mock
    private InventoryService inventoryService;

    @InjectMocks
    private InventoryController inventoryController;

    private InventoryBalance inventory;
    private StockTransactionRequest transactionRequest;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        inventory = new InventoryBalance();
        inventory.setBalanceId(1L);
        inventory.setBloodGroup("O+");
        inventory.setQuantity(100);

        transactionRequest = new StockTransactionRequest();
        transactionRequest.setComponentId(1L);
        transactionRequest.setQuantity(10);
        transactionRequest.setTxnType(com.donorconnect.enums.Enums.TransactionType.RECEIPT);
    }

    @Test
    @DisplayName("Should get all inventory balances successfully")
    void testGetAllInventorySuccess() {
        List<InventoryBalance> inventories = new ArrayList<>();
        inventories.add(inventory);

        when(inventoryService.getAll()).thenReturn(inventories);

        ResponseEntity<ApiResponse<?>> response = inventoryController.getAll();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
        assertNotNull(response.getBody().getData());
    }

    @Test
    @DisplayName("Should record stock transaction successfully")
    void testRecordTransactionSuccess() {
        when(inventoryService.createTransaction(any(StockTransactionRequest.class)))
                .thenReturn(new com.donorconnect.entity.inventory.StockTransaction());

        ResponseEntity<ApiResponse<?>> response = inventoryController.createTransaction(transactionRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should get inventory by blood group successfully")
    void testGetByBloodGroupSuccess() {
        List<InventoryBalance> inventories = new ArrayList<>();
        inventories.add(inventory);

        when(inventoryService.getByBloodGroup("O+")).thenReturn(inventories);

        ResponseEntity<ApiResponse<?>> response = inventoryController.getByBloodGroup("O+");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should get low stock successfully")
    void testGetLowStockSuccess() {
        List<InventoryBalance> low = new ArrayList<>();
        low.add(inventory);

        when(inventoryService.getLowStock()).thenReturn(low);

        ResponseEntity<ApiResponse<?>> response = inventoryController.getLowStock();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }
}
