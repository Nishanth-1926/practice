package com.donorconnect.controller.reaction;

import com.donorconnect.dto.request.reaction.ReactionRequest;
import com.donorconnect.dto.response.ApiResponse;
import com.donorconnect.entity.reaction.Reaction;
import com.donorconnect.service.reaction.ReactionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@DisplayName("ReactionController Test Suite")
public class ReactionControllerTest {

    @Mock
    private ReactionService reactionService;

    @InjectMocks
    private ReactionController reactionController;

    private Reaction testReaction;
    private ReactionRequest reactionRequest;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        testReaction = new Reaction();
        testReaction.setReactionId(1L);
        testReaction.setIssueId(1L);
        testReaction.setReactionType("MILD");
        testReaction.setNotes("Mild reaction reported");
        testReaction.setStatus(com.donorconnect.enums.Enums.ReactionStatus.PENDING);

        reactionRequest = new ReactionRequest();
        reactionRequest.setIssueId(1L);
        reactionRequest.setReactionType("MILD");
        reactionRequest.setNotes("Mild reaction reported");
    }

    @Test
    @DisplayName("Should report reaction successfully")
    void testReportReactionSuccess() {
        when(reactionService.create(any(ReactionRequest.class))).thenReturn(testReaction);

        ResponseEntity<ApiResponse<?>> response = reactionController.createReaction(reactionRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
        assertNotNull(response.getBody().getData());
    }

    @Test
    @DisplayName("Should get reaction by ID successfully")
    void testGetReactionByIdSuccess() {
        when(reactionService.getById(1L)).thenReturn(testReaction);

        ResponseEntity<ApiResponse<?>> response = reactionController.getReactionById(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should get all reactions successfully")
    void testGetAllReactionsSuccess() {
        List<Reaction> reactions = new ArrayList<>();
        reactions.add(testReaction);

        when(reactionService.getAll(any(org.springframework.data.domain.Pageable.class)))
                .thenReturn(new org.springframework.data.domain.PageImpl<>(reactions));

        ResponseEntity<ApiResponse<?>> response = reactionController.getAllReactions(0, 20);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should get reactions by patient ID successfully")
    void testGetByPatientIdSuccess() {
        List<Reaction> reactions = new ArrayList<>();
        reactions.add(testReaction);

        when(reactionService.getReactionsByPatient(1L)).thenReturn(reactions);

        ResponseEntity<ApiResponse<?>> response = reactionController.getReactionsByPatient(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should update reaction successfully")
    void testUpdateReactionSuccess() {
        when(reactionService.update(1L, reactionRequest)).thenReturn(testReaction);

        ResponseEntity<ApiResponse<?>> response = reactionController.updateReaction(1L, reactionRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should get reactions by severity successfully")
    void testGetBySeveritySuccess() {
        List<Reaction> reactions = new ArrayList<>();
        reactions.add(testReaction);

        when(reactionService.getBySeverity(com.donorconnect.enums.Enums.ReactionSeverity.MILD)).thenReturn(reactions);

        ResponseEntity<ApiResponse<?>> response = reactionController.getReactionsBySeverity(com.donorconnect.enums.Enums.ReactionSeverity.MILD);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }
}
