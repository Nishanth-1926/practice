package com.donorconnect.controller.auth;

import com.donorconnect.dto.request.auth.UpdateUserRequest;
import com.donorconnect.dto.response.ApiResponse;
import com.donorconnect.entity.auth.User;
import com.donorconnect.service.auth.AuthService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@DisplayName("UserController Test Suite")
public class UserControllerTest {

    @Mock
    private AuthService authService;

    @Mock
    private Authentication authentication;

    @InjectMocks
    private UserController userController;

    private User testUser;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        testUser = new User();
        testUser.setUserId(1L);
        testUser.setEmail("user@test.com");
        testUser.setName("Test User");
    }

    @Test
    @DisplayName("Should update user successfully")
    void testUpdateUserSuccess() {
        UpdateUserRequest request = new UpdateUserRequest();
        request.setName("Updated Name");
        request.setPhone("1234567890");

        when(authService.updateUser(1L, request)).thenReturn(testUser);

        ResponseEntity<ApiResponse<?>> response = userController.updateUser(1L, request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should get all users successfully")
    void testGetAllUsersSuccess() {
        List<User> users = new ArrayList<>();
        users.add(testUser);

        when(authService.getAllUsers(any(org.springframework.data.domain.Pageable.class)))
                .thenReturn(new org.springframework.data.domain.PageImpl<>(users));

        ResponseEntity<ApiResponse<?>> response = userController.getAllUsers(0, 20);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
        assertNotNull(response.getBody().getData());
    }

    @Test
    @DisplayName("Should get user by ID successfully")
    void testGetUserByIdSuccess() {
        when(authService.getUserById(1L)).thenReturn(testUser);

        ResponseEntity<ApiResponse<?>> response = userController.getUserById(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should lock user successfully")
    void testLockUserSuccess() {
        doNothing().when(authService).lockUser(1L);

        ResponseEntity<ApiResponse<?>> response = userController.lockUser(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }
}
