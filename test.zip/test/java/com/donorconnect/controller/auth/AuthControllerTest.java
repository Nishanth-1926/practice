package com.donorconnect.controller.auth;

import com.donorconnect.dto.request.auth.*;
import com.donorconnect.dto.response.ApiResponse;
import com.donorconnect.entity.auth.User;
import com.donorconnect.enums.Enums.*;
import com.donorconnect.repository.auth.UserRepository;
import com.donorconnect.service.auth.AuthService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@DisplayName("AuthController Test Suite")
public class AuthControllerTest {

    @Mock
    private AuthService authService;

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private Authentication authentication;

    @InjectMocks
    private AuthController authController;

    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(authController).build();
    }

    @Test
    @DisplayName("Should setup admin successfully when no admin exists")
    void testSetupAdminSuccess() {
        Setupadminrequest request = new Setupadminrequest();
        request.setName("Admin User");
        request.setEmail("admin@test.com");
        request.setPhone("1234567890");
        request.setPassword("password123");

        when(userRepository.findByRole(UserRole.ROLE_ADMIN)).thenReturn(new ArrayList<>());
        when(passwordEncoder.encode(request.getPassword())).thenReturn("encodedPassword");
        when(userRepository.save(any(User.class))).thenReturn(new User());

        ResponseEntity<ApiResponse<?>> response = authController.setupAdmin(request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should fail to setup admin when admin already exists")
    void testSetupAdminFailsWhenAdminExists() {
        Setupadminrequest request = new Setupadminrequest();
        request.setEmail("admin@test.com");

        User existingAdmin = new User();
        when(userRepository.findByRole(UserRole.ROLE_ADMIN)).thenReturn(new ArrayList<>() {{
            add(existingAdmin);
        }});

        ResponseEntity<ApiResponse<?>> response = authController.setupAdmin(request);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertFalse(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should login successfully with valid credentials")
    void testLoginSuccess() {
        LoginRequest request = new LoginRequest();
        request.setEmail("user@test.com");
        request.setPassword("password123");

        Map<String, String> loginResult = new HashMap<>();
        loginResult.put("token", "jwt-token-here");
        loginResult.put("role", "ROLE_DONOR");
        loginResult.put("email", "user@test.com");
        loginResult.put("name", "User Test");

        when(authService.login(request)).thenReturn(loginResult);

        ResponseEntity<ApiResponse<?>> response = authController.login(request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().isSuccess());
        assertNotNull(response.getBody().getData());
    }

    @Test
    @DisplayName("Should fail login with invalid credentials")
    void testLoginFailure() {
        LoginRequest request = new LoginRequest();
        request.setEmail("invalid@test.com");
        request.setPassword("wrongpassword");

        when(authService.login(request)).thenThrow(new RuntimeException("Invalid credentials"));

        ResponseEntity<ApiResponse<?>> response = authController.login(request);

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertFalse(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should register user successfully with admin token")
    void testRegisterSuccess() {
        RegisterRequest request = new RegisterRequest();
        request.setEmail("newuser@test.com");
        request.setName("New User");
        request.setPassword("password123");
        request.setRole(UserRole.ROLE_DONOR);

        User registeredUser = new User();
        registeredUser.setUserId(2L);
        registeredUser.setEmail(request.getEmail());
        registeredUser.setName(request.getName());
        registeredUser.setRole(request.getRole());

        when(authService.register(request)).thenReturn(registeredUser);

        ResponseEntity<ApiResponse<?>> response = authController.register(request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should change password successfully")
    void testChangePasswordSuccess() {
        ChangePasswordRequest request = new ChangePasswordRequest();
        request.setOldPassword("oldpass");
        request.setNewPassword("newpass");

        when(authentication.getName()).thenReturn("user@test.com");
        doNothing().when(authService).changePassword("user@test.com", request);

        ResponseEntity<ApiResponse<?>> response = authController.changePassword(request, authentication);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should handle forgot password request")
    void testForgotPasswordSuccess() {
        String email = "user@test.com";
        when(authService.forgotPassword(email)).thenReturn("Password reset email sent");

        ResponseEntity<ApiResponse<?>> response = authController.forgotPassword(email);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should reset password successfully")
    void testResetPasswordSuccess() {
        ResetPasswordRequest request = new ResetPasswordRequest();
        request.setToken("reset-token");
        request.setNewPassword("newpass123");

        when(authService.resetPassword(request)).thenReturn("Password reset successfully");

        ResponseEntity<ApiResponse<?>> response = authController.resetPassword(request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().isSuccess());
    }
}
