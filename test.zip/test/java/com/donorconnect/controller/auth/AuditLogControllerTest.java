package com.donorconnect.controller.auth;

import com.donorconnect.service.auth.AuthService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AuditLogController.class)
@AutoConfigureMockMvc(addFilters = false)
class AuditLogControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AuthService authService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @WithMockUser(roles = "ADMIN")
    void getAll() throws Exception {
        Mockito.when(authService.getAllAuditLogs(Mockito.any(PageRequest.class)))
                .thenReturn(Page.empty());

        mockMvc.perform(get("/api/v1/audit-logs")
                        .param("page", "0")
                        .param("size", "20"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void getByUser() throws Exception {
        Mockito.when(authService.getAuditLogsByUser(1L))
                .thenReturn(List.of());

        mockMvc.perform(get("/api/v1/audit-logs/user/1"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void getByAction() throws Exception {
        Mockito.when(authService.getAuditLogsByAction("LOGIN"))
                .thenReturn(List.of());

        mockMvc.perform(get("/api/v1/audit-logs/action/LOGIN"))
                .andExpect(status().isOk());
    }
}