package com.donorconnect.controller.collection;

import com.donorconnect.dto.request.collection.DonationRequest;
import com.donorconnect.dto.response.ApiResponse;
import com.donorconnect.entity.collection.Donation;
import com.donorconnect.service.collection.DonationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@DisplayName("DonationController Test Suite")
public class DonationControllerTest {

    @Mock
    private DonationService donationService;

    @InjectMocks
    private DonationController donationController;

    private Donation testDonation;
    private DonationRequest donationRequest;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        testDonation = new Donation();
        testDonation.setDonationId(1L);
        testDonation.setDonorId(1L);
        testDonation.setBagId("bag-123");
        testDonation.setVolumeMl(450);
        testDonation.setCollectionStatus(com.donorconnect.enums.Enums.CollectionStatus.COLLECTED);

        donationRequest = new DonationRequest();
        donationRequest.setDonorId(1L);
        donationRequest.setBagId("bag-123");
        donationRequest.setVolumeMl(450);
    }

    @Test
    @DisplayName("Should record donation successfully")
    void testRecordDonationSuccess() {
        when(donationService.create(any(DonationRequest.class))).thenReturn(testDonation);

        ResponseEntity<ApiResponse<?>> response = donationController.create(donationRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
        assertNotNull(response.getBody().getData());
    }

    @Test
    @DisplayName("Should get donation by ID successfully")
    void testGetDonationByIdSuccess() {
        when(donationService.getById(1L)).thenReturn(testDonation);

        ResponseEntity<ApiResponse<?>> response = donationController.getById(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should get all donations successfully")
    void testGetAllDonationsSuccess() {
        List<Donation> donations = new ArrayList<>();
        donations.add(testDonation);

        when(donationService.getAll(any(org.springframework.data.domain.Pageable.class)))
                .thenReturn(new org.springframework.data.domain.PageImpl<>(donations));

        ResponseEntity<ApiResponse<?>> response = donationController.getAll(0, 20);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should update donation successfully")
    void testUpdateDonationSuccess() {
        when(donationService.update(1L, donationRequest)).thenReturn(testDonation);

        ResponseEntity<ApiResponse<?>> response = donationController.update(1L, donationRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should get donations by donor ID successfully")
    void testGetDonationsByDonorSuccess() {
        List<Donation> donations = new ArrayList<>();
        donations.add(testDonation);

        when(donationService.getByDonor(1L)).thenReturn(donations);

        ResponseEntity<ApiResponse<?>> response = donationController.getByDonor(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should get donation by bag ID successfully")
    void testGetDonationByBagIdSuccess() {
        when(donationService.getByBagId("bag-123")).thenReturn(testDonation);

        ResponseEntity<ApiResponse<?>> response = donationController.getByBagId("bag-123");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should update donation status successfully")
    void testUpdateDonationStatusSuccess() {
        when(donationService.updateStatus(eq(1L), any())).thenReturn(testDonation);

        ResponseEntity<ApiResponse<?>> response = donationController.updateStatus(1L, com.donorconnect.enums.Enums.CollectionStatus.COLLECTED);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }
}
