package com.donorconnect.controller.notification;

import com.donorconnect.dto.request.notification.NotificationRequest;
import com.donorconnect.dto.response.ApiResponse;
import com.donorconnect.entity.notification.Notification;
import com.donorconnect.service.notification.NotificationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@DisplayName("NotificationController Test Suite")
public class NotificationControllerTest {

    @Mock
    private NotificationService notificationService;

    @InjectMocks
    private NotificationController notificationController;

    private Notification testNotification;
    private NotificationRequest notificationRequest;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        testNotification = new Notification();
        testNotification.setNotificationId(1L);
        testNotification.setUserId(1L);
        testNotification.setMessage("Test message");
        testNotification.setStatus(com.donorconnect.enums.Enums.NotificationStatus.UNREAD);

        notificationRequest = new NotificationRequest();
        notificationRequest.setUserId(1L);
        notificationRequest.setMessage("Test message");
    }

    @Test
    @DisplayName("Should create notification successfully")
    void testCreateNotificationSuccess() {
        when(notificationService.create(any(NotificationRequest.class))).thenReturn(testNotification);

        ResponseEntity<ApiResponse<?>> response = notificationController.create(notificationRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
        assertNotNull(response.getBody().getData());
    }

    

    @Test
    @DisplayName("Should get current user's notifications successfully")
    void testGetMineSuccess() {
        List<Notification> notifications = new ArrayList<>();
        notifications.add(testNotification);

        org.springframework.security.core.Authentication auth = mock(org.springframework.security.core.Authentication.class);
        com.donorconnect.entity.auth.User u = com.donorconnect.entity.auth.User.builder().userId(1L).email("user@test.com").build();
        when(auth.getPrincipal()).thenReturn(u);

        when(notificationService.getForUser(1L)).thenReturn(notifications);

        ResponseEntity<ApiResponse<?>> response = notificationController.getMine(auth);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should get notification by ID successfully")
    void testGetNotificationByIdSuccess() {
        when(notificationService.getById(1L)).thenReturn(testNotification);

        ResponseEntity<ApiResponse<?>> response = notificationController.getById(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should mark notification as read successfully")
    void testMarkAsReadSuccess() {
        when(notificationService.markRead(1L)).thenReturn(testNotification);

        ResponseEntity<ApiResponse<?>> response = notificationController.markRead(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should delete notification successfully")
    void testDeleteNotificationSuccess() {
        doNothing().when(notificationService).delete(1L);

        ResponseEntity<ApiResponse<?>> response = notificationController.delete(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should get unread notifications successfully")
    void testGetUnreadSuccess() {
        org.springframework.security.core.Authentication auth = mock(org.springframework.security.core.Authentication.class);
        com.donorconnect.entity.auth.User u = com.donorconnect.entity.auth.User.builder().userId(1L).email("user@test.com").build();
        when(auth.getPrincipal()).thenReturn(u);

        List<Notification> unread = new ArrayList<>();
        unread.add(testNotification);

        when(notificationService.getUnreadForUser(1L)).thenReturn(unread);

        ResponseEntity<ApiResponse<?>> response = notificationController.getUnread(auth);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }
}
