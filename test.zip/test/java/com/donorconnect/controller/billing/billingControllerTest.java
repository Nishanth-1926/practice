package com.donorconnect.controller.billing;

import com.donorconnect.dto.request.billing.BillingRequest;
import com.donorconnect.enums.Enums.BillingStatus;
import com.donorconnect.service.billing.BillingService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(BillingController.class)
@AutoConfigureMockMvc(addFilters = false)
class BillingControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BillingService billingService;

    @Autowired
    private ObjectMapper objectMapper;

    private BillingRequest request() {
        return new BillingRequest();
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void create() throws Exception {
        Mockito.when(billingService.create(Mockito.any()))
                .thenReturn(null);

        mockMvc.perform(post("/api/v1/billing")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Billing record created"));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void getAll() throws Exception {
        Mockito.when(billingService.getAll(Mockito.any(PageRequest.class)))
                .thenReturn(Page.empty());

        mockMvc.perform(get("/api/v1/billing")
                        .param("page", "0")
                        .param("size", "20"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void getById() throws Exception {
        Mockito.when(billingService.getById(1L))
                .thenReturn(null);

        mockMvc.perform(get("/api/v1/billing/1"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void getByIssue() throws Exception {
        Mockito.when(billingService.getByIssue(1L))
                .thenReturn(null);

        mockMvc.perform(get("/api/v1/billing/issue/1"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void export() throws Exception {
        Mockito.when(billingService.exportByDateRange(Mockito.any(LocalDate.class), Mockito.any(LocalDate.class)))
                ;

        mockMvc.perform(get("/api/v1/billing/export")
                        .param("from", "2024-01-01")
                        .param("to", "2024-01-31"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void updateStatus() throws Exception {
        Mockito.when(billingService.updateStatus(1L, BillingStatus.PAID))
                .thenReturn(null);

        mockMvc.perform(patch("/api/v1/billing/1/status")
                        .param("status", "PAID"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Status updated"));
    }
}