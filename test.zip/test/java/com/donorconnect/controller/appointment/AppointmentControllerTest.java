package com.donorconnect.controller.appointment;

import com.donorconnect.dto.request.appointment.AppointmentRequest;
import com.donorconnect.dto.response.ApiResponse;
import com.donorconnect.entity.appointment.DonationAppointment;
import com.donorconnect.service.appointment.AppointmentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@DisplayName("AppointmentController Test Suite")
public class AppointmentControllerTest {

    @Mock
    private AppointmentService appointmentService;

    @InjectMocks
    private AppointmentController appointmentController;

    private DonationAppointment testAppointment;
    private AppointmentRequest appointmentRequest;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        testAppointment = new DonationAppointment();
        testAppointment.setAppointmentId(1L);
        testAppointment.setDonorId(1L);
        testAppointment.setDriveId(1L);
        testAppointment.setStatus(com.donorconnect.enums.Enums.AppointmentStatus.BOOKED);

        appointmentRequest = new AppointmentRequest();
        appointmentRequest.setDonorId(1L);
        appointmentRequest.setDriveId(1L);
    }

    @Test
    @DisplayName("Should book appointment successfully")
    void testBookAppointmentSuccess() {
        when(appointmentService.book(any(AppointmentRequest.class))).thenReturn(testAppointment);

        ResponseEntity<ApiResponse<?>> response = appointmentController.book(appointmentRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
        assertNotNull(response.getBody().getData());
    }

    @Test
    @DisplayName("Should get appointment by ID successfully")
    void testGetAppointmentByIdSuccess() {
        when(appointmentService.getById(1L)).thenReturn(testAppointment);

        ResponseEntity<ApiResponse<?>> response = appointmentController.getById(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should get all appointments successfully")
    void testGetAllAppointmentsSuccess() {
        List<DonationAppointment> appointments = new ArrayList<>();
        appointments.add(testAppointment);

        when(appointmentService.getAll(any(org.springframework.data.domain.Pageable.class)))
                .thenReturn(new org.springframework.data.domain.PageImpl<>(appointments));

        ResponseEntity<ApiResponse<?>> response = appointmentController.getAll(0, 20);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should update appointment successfully")
    void testUpdateAppointmentSuccess() {
        when(appointmentService.update(1L, appointmentRequest)).thenReturn(testAppointment);

        ResponseEntity<ApiResponse<?>> response = appointmentController.update(1L, appointmentRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should cancel appointment successfully")
    void testCancelAppointmentSuccess() {
        when(appointmentService.updateStatus(1L, any())).thenReturn(testAppointment);

        ResponseEntity<ApiResponse<?>> response = appointmentController.cancel(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should get appointments by donor ID successfully")
    void testGetAppointmentsByDonorSuccess() {
        List<DonationAppointment> appointments = new ArrayList<>();
        appointments.add(testAppointment);

        when(appointmentService.getByDonor(1L)).thenReturn(appointments);

        ResponseEntity<ApiResponse<?>> response = appointmentController.getByDonor(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }

    @Test
    @DisplayName("Should check-in appointment successfully")
    void testCheckInAppointmentSuccess() {
        when(appointmentService.updateStatus(1L, any())).thenReturn(testAppointment);

        ResponseEntity<ApiResponse<?>> response = appointmentController.checkIn(1L);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().isSuccess());
    }
}

