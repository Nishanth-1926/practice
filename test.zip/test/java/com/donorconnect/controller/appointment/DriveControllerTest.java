package com.donorconnect.controller.appointment;

import com.donorconnect.dto.request.appointment.DriveRequest;
import com.donorconnect.security.JwtTokenProvider;
import com.donorconnect.service.appointment.DriveService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(DriveController.class)
@AutoConfigureMockMvc(addFilters = false)
class DriveControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private DriveService driveService;

    @MockBean
    private JwtTokenProvider jwtTokenProvider;

    @Autowired
    private ObjectMapper objectMapper;

    private DriveRequest request() {
        return new DriveRequest();
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void create() throws Exception {
        Mockito.when(driveService.create(Mockito.any()))
                .thenReturn(null);

        mockMvc.perform(post("/api/v1/drives")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Drive created"));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void getAll() throws Exception {
        Mockito.when(driveService.getAll())
                .thenReturn(List.of());

        mockMvc.perform(get("/api/v1/drives"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(roles = "RECEPTION")
    void getById() throws Exception {
        Mockito.when(driveService.getById(1L))
                .thenReturn(null);

        mockMvc.perform(get("/api/v1/drives/1"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(roles = "RECEPTION")
    void getUpcoming() throws Exception {
        Mockito.when(driveService.getUpcoming())
                .thenReturn(List.of());

        mockMvc.perform(get("/api/v1/drives/upcoming"))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void update() throws Exception {
        Mockito.when(driveService.update(Mockito.eq(1L), Mockito.any()))
                .thenReturn(null);

        mockMvc.perform(put("/api/v1/drives/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request())))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Drive updated"));
    }

    @Test
    @WithMockUser(roles = "ADMIN")
    void updateStatus() throws Exception {
        Mockito.when(driveService.updateStatus(Mockito.eq(1L), Mockito.any()))
                .thenReturn(null);

        mockMvc.perform(patch("/api/v1/drives/1/status")
                        .param("status", "ACTIVE"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Status updated"));
    }

    @Test
    @WithMockUser(roles = "RECEPTION")
    void getAppointments() throws Exception {
        Mockito.when(driveService.getAppointmentsByDrive(1L))
                .thenReturn(List.of());

        mockMvc.perform(get("/api/v1/drives/1/appointments"))
                .andExpect(status().isOk());
    }
}